#!/usr/bin/env bash
set -e

echo "Waiting for Postgres to be ready..."
for i in {1..20}; do
  if pg_isready -h localhost -p 5432 > /dev/null 2>&1; then
    break
  fi
  sleep 1
done

echo "Creating database if it doesn't exist..."
PGPASSWORD=postgres psql -h localhost -U postgres -tc \
  "SELECT 1 FROM pg_database WHERE datname = 'leftover_alchemist'" | grep -q 1 || \
PGPASSWORD=postgres psql -h localhost -U postgres -c "CREATE DATABASE leftover_alchemist"

echo "Running migration..."
PGPASSWORD=postgres psql -h localhost -U postgres -d leftover_alchemist -f migrations/001_init.sql

echo "Done. DB ready at postgres://postgres:postgres@localhost:5432/leftover_alchemist"
