const express = require('express');
const rateLimit = require('express-rate-limit');
const { pool } = require('../db');

const router = express.Router();

// Recipe generation is cheap (text completion), so it's not capped for
// monetization purposes — but it's still rate-limited to stop abuse/scraping.
const recipeRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 30,
  message: { error: 'Too many recipe requests. Try again later.' },
});

// Stub — replace with a real call to your recipe-generation model.
async function generateRecipe({ ingredients, timeMinutes, servings, dietaryNotes }) {
  return {
    title: 'Quick Fried Rice with Leftover Veggies',
    ingredients: ingredients.map((i) => ({ name: i, amount: 'to taste' })),
    steps: [
      'Heat oil in a pan over medium-high heat.',
      'Add chopped vegetables, stir-fry 3-4 minutes.',
      'Add rice, break up clumps, stir-fry another 3 minutes.',
      'Season and serve.',
    ],
    time_minutes: timeMinutes || 15,
  };
}

// POST /recipes  { photoId?, timeMinutes?, servings?, dietaryNotes? }
// Generates from a photo's detected_items, or from pantry staples if no photoId given.
router.post('/', recipeRateLimit, async (req, res, next) => {
  try {
    const { photoId, timeMinutes, servings, dietaryNotes } = req.body;

    let ingredients = [];
    if (photoId) {
      const photoResult = await pool.query(
        `SELECT detected_items FROM photos WHERE id = $1 AND user_id = $2`,
        [photoId, req.user.id]
      );
      if (photoResult.rows.length === 0) {
        return res.status(404).json({ error: 'Photo not found' });
      }
      ingredients = photoResult.rows[0].detected_items || [];
    } else {
      const staplesResult = await pool.query(
        `SELECT name FROM pantry_staples WHERE user_id = $1`,
        [req.user.id]
      );
      ingredients = staplesResult.rows.map((r) => r.name);
    }

    const generated = await generateRecipe({ ingredients, timeMinutes, servings, dietaryNotes });

    const saved = await pool.query(
      `INSERT INTO recipes (user_id, photo_id, title, ingredients, steps, time_minutes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [
        req.user.id,
        photoId || null,
        generated.title,
        JSON.stringify(generated.ingredients),
        JSON.stringify(generated.steps),
        generated.time_minutes,
      ]
    );

    res.status(201).json({ recipe: saved.rows[0] });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
