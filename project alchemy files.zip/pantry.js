const express = require('express');
const { pool } = require('../db');

const router = express.Router();

// GET /pantry
router.get('/', async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT * FROM pantry_staples WHERE user_id = $1 ORDER BY added_at DESC`,
      [req.user.id]
    );
    res.json({ staples: result.rows });
  } catch (err) {
    next(err);
  }
});

// POST /pantry  { name }
router.post('/', async (req, res, next) => {
  try {
    const { name } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required' });

    const result = await pool.query(
      `INSERT INTO pantry_staples (user_id, name) VALUES ($1, $2) RETURNING *`,
      [req.user.id, name]
    );
    res.status(201).json({ staple: result.rows[0] });
  } catch (err) {
    next(err);
  }
});

// DELETE /pantry/:id
router.delete('/:id', async (req, res, next) => {
  try {
    await pool.query(
      `DELETE FROM pantry_staples WHERE id = $1 AND user_id = $2`,
      [req.params.id, req.user.id]
    );
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

module.exports = router;
