const { pool } = require('../db');

const FREE_PHOTO_CAP = 3; // per month — tune based on paywall_events data post-launch

// Returns the first/last day of the current calendar month.
// Swap this out if you want billing-cycle-based periods instead of calendar months.
function currentPeriodBounds() {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), 1);
  const end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  const fmt = (d) => d.toISOString().slice(0, 10);
  return { periodStart: fmt(start), periodEnd: fmt(end) };
}

// Lazily fetches the user's current usage_periods row, creating one if the
// existing row (if any) has expired or doesn't exist yet. No cron job needed for v1.
async function getOrCreateCurrentPeriod(userId) {
  const { periodStart, periodEnd } = currentPeriodBounds();

  const existing = await pool.query(
    `SELECT * FROM usage_periods WHERE user_id = $1 AND period_start = $2`,
    [userId, periodStart]
  );
  if (existing.rows.length > 0) return existing.rows[0];

  const inserted = await pool.query(
    `INSERT INTO usage_periods (user_id, period_start, period_end, photos_used)
     VALUES ($1, $2, $3, 0)
     ON CONFLICT (user_id, period_start) DO UPDATE SET period_start = EXCLUDED.period_start
     RETURNING *`,
    [userId, periodStart, periodEnd]
  );
  return inserted.rows[0];
}

// Express middleware: attach req.usagePeriod, and reject the request outright
// if a free user is already at the cap. Paid users skip the check entirely.
async function enforcePhotoCap(req, res, next) {
  try {
    const user = req.user; // assumes auth middleware has already set this
    if (!user) return res.status(401).json({ error: 'Not authenticated' });

    if (user.plan === 'paid') {
      req.usagePeriod = null;
      req.photoCapWarning = null;
      return next();
    }

    const period = await getOrCreateCurrentPeriod(user.id);

    if (period.photos_used >= FREE_PHOTO_CAP) {
      await pool.query(
        `INSERT INTO paywall_events (user_id, trigger) VALUES ($1, 'photo_cap')`,
        [user.id]
      );
      return res.status(402).json({
        error: 'upgrade_required',
        message: `You've used all ${FREE_PHOTO_CAP} free photos this month. Upgrade for unlimited.`,
      });
    }

    // Surface a warning to the frontend on the second-to-last free photo,
    // so the paywall doesn't feel like an ambush.
    req.usagePeriod = period;
    req.photoCapWarning =
      period.photos_used === FREE_PHOTO_CAP - 1
        ? `${FREE_PHOTO_CAP - period.photos_used - 1} photo left this month`
        : null;

    next();
  } catch (err) {
    next(err);
  }
}

// Call this after a photo upload successfully completes.
async function incrementPhotoUsage(userId, periodStart) {
  await pool.query(
    `UPDATE usage_periods SET photos_used = photos_used + 1
     WHERE user_id = $1 AND period_start = $2`,
    [userId, periodStart]
  );
}

module.exports = { enforcePhotoCap, incrementPhotoUsage, FREE_PHOTO_CAP };
