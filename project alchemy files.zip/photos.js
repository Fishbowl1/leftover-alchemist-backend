const express = require('express');
const { pool } = require('../db');
const { enforcePhotoCap, incrementPhotoUsage } = require('../middleware/usageCap');

const router = express.Router();

// Stub — replace with a real call to your vision/ingredient-detection API.
async function detectIngredients(imageUrl) {
  // e.g. call OpenAI/Claude vision, Google Vision, etc.
  return ['onion', 'half a bell pepper', 'leftover rice'];
}

// POST /photos  { imageUrl }
// Assumes an upstream step has already uploaded the raw file to S3/etc.
// and passed back a URL — this route doesn't handle multipart upload itself.
router.post('/', enforcePhotoCap, async (req, res, next) => {
  try {
    const { imageUrl } = req.body;
    if (!imageUrl) return res.status(400).json({ error: 'imageUrl is required' });

    const detectedItems = await detectIngredients(imageUrl);

    const result = await pool.query(
      `INSERT INTO photos (user_id, image_url, detected_items)
       VALUES ($1, $2, $3) RETURNING *`,
      [req.user.id, imageUrl, JSON.stringify(detectedItems)]
    );

    // Only free-tier users have a usagePeriod (paid users skip the cap entirely).
    if (req.usagePeriod) {
      await incrementPhotoUsage(req.user.id, req.usagePeriod.period_start);
    }

    res.status(201).json({
      photo: result.rows[0],
      warning: req.photoCapWarning || undefined,
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
