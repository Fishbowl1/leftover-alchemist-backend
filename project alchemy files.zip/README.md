# Leftover Alchemist — Backend

## Setup

```bash
npm install
createdb leftover_alchemist
export DATABASE_URL=postgres://localhost:5432/leftover_alchemist
npm run migrate
npm start
```

## How the free/paid split works

- **Photo uploads are capped at 3/month for free-tier users.** This is the
  expensive operation (vision API call), so it's the one tied to monetization.
- **Recipe generation is uncapped** on free tier — it's cheap (text
  completion) and gating it would just frustrate people without protecting
  margin. It's rate-limited (30/hour) purely to prevent abuse.
- At the 2nd of 3 free photos, the API returns a `warning` field so the
  frontend can show "1 photo left this month" *before* the wall, not after.
- Every time a free user hits the cap, a row is written to `paywall_events`.
  After launch, query this table to see your actual paywall-hit rate — that's
  the real data you need to decide whether 3/month is too tight, too loose,
  or just right, rather than guessing.
- `usage_periods` resets lazily (no cron job needed for v1): the first
  request in a new calendar month just creates a fresh row.

## What's stubbed and needs real implementations before launch

- `detectIngredients()` in `src/routes/photos.js` — plug in a real vision
  API (Claude, GPT-4V, Google Vision, etc.)
- `generateRecipe()` in `src/routes/recipes.js` — plug in a real recipe
  generation model/prompt
- `src/middleware/auth.js` — this is a placeholder that trusts an
  `x-user-id` header. Replace with real JWT or session-based auth before
  anything is exposed publicly.
- Stripe integration — `stripe_customer_id` exists on the `users` table so
  the upgrade flow has somewhere to write to, but no billing code is wired
  up yet.

## Changing the cap model

If you'd rather use lifetime caps instead of monthly recurring ones, the
only place that needs to change is `currentPeriodBounds()` in
`src/middleware/usageCap.js` — everything else (schema, warning logic,
paywall logging) works the same either way.
