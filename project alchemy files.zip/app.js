const express = require('express');
const { requireAuth } = require('./middleware/auth');
const photosRouter = require('./routes/photos');
const recipesRouter = require('./routes/recipes');
const pantryRouter = require('./routes/pantry');

const app = express();
app.use(express.json());

app.use('/photos', requireAuth, photosRouter);
app.use('/recipes', requireAuth, recipesRouter);
app.use('/pantry', requireAuth, pantryRouter);

app.get('/health', (req, res) => res.json({ ok: true }));

// Centralized error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Leftover Alchemist API listening on :${PORT}`));

module.exports = app;
