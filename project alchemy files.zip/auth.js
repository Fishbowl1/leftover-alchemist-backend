const { pool } = require('../db');

// PLACEHOLDER auth — replace with real JWT/session verification before launch.
// Expects a header: x-user-id: <id>  (for local testing only)
async function requireAuth(req, res, next) {
  try {
    const userId = req.headers['x-user-id'];
    if (!userId) return res.status(401).json({ error: 'Not authenticated' });

    const result = await pool.query(`SELECT * FROM users WHERE id = $1`, [userId]);
    if (result.rows.length === 0) return res.status(401).json({ error: 'Not authenticated' });

    req.user = result.rows[0];
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { requireAuth };
