const { Pool } = require('pg');

// DATABASE_URL, e.g. postgres://user:pass@localhost:5432/leftover_alchemist
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

module.exports = { pool };
