'use strict';
const db = require('../src/db');
const photos = require('../src/services/photos');
photos.cleanup().then((r) => { console.log('cleanup done', r); return db.close(); }).catch((e) => { console.error(e); process.exit(1); });
