'use strict';
// Usage: node scripts/set-plan.js user@example.com paid|free   (manual upgrade until Play Billing is wired in)
const db = require('../src/db');
const [email, plan] = process.argv.slice(2);
if (!email || !['free', 'paid'].includes(plan)) { console.error('Usage: node scripts/set-plan.js <email> <free|paid>'); process.exit(1); }
db.query('UPDATE users SET plan = $1 WHERE email = $2 RETURNING id', [plan, email.toLowerCase()])
  .then((r) => { console.log(r.rowCount ? `Set ${email} to ${plan}` : 'No such user'); return db.close(); })
  .catch((e) => { console.error(e); process.exit(1); });
