# Leftover Alchemist backend

Fridge photo -> pantry -> safe recipes. Node 20.12+, Express, Postgres, sharp.

## Run
```
npm install
cp .env.example .env     # add DATABASE_URL and ANTHROPIC_API_KEY
npm start                # migrates the database automatically, then listens on :3000
```
Test (uses a throwaway DB; its name must contain "test", it is wiped each run):
```
createdb leftover_test
TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/leftover_test npm test
```
Make someone a paid user: `npm run set-plan -- you@example.com paid`.

## API (all but /auth and /health need `Authorization: Bearer <token>`)
- `POST /auth/signup|login|logout`; `GET/DELETE /me`; `GET /me/export`; `GET/PUT /me/preferences`
- `POST /photos` (raw image body, `?autoAdd=true`), `GET /photos`, `POST /photos/:id/analyze|confirm`, `DELETE /photos/:id`
- `GET/POST /pantry`, `PATCH/DELETE /pantry/:id`, `POST /pantry/:id/discard|used-up`
- `POST /recipes/generate`, `GET /recipes`, `GET /recipes/:id?servings=`, `POST /recipes/:id/cook|shopping-list`
- `GET/POST /shopping-list...`, `POST /shopping-list/purchase`, `GET /stats`

## Not verified yet
The AI request format and model names, real prices (`AI_PRICES_JSON`), and image storage beyond Postgres (S3) have not been tested against live services. Allergy checks are keyword based and a safety aid only, not a guarantee.
