'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { interpret } = require('../src/ai/vision');
const { rateLimit } = require('../src/middleware/common');

const A = { contains_people: false, inappropriate_content: false, is_food_scene: true, image_quality: 'good' };
const it = (o) => ({ name: 'tomato', category: 'produce', storage: 'fridge', quantity: 2, unit: 'count', quantity_confidence: 0.9, freshness: 'fresh', freshness_signals: [], est_days_remaining: 5, label_expiry_date: null, confidence: 0.9, ...o });
const TODAY = '2026-10-10';

test('interpret merges duplicates, keeps earliest expiry and worst freshness', () => {
  const out = interpret({ assessment: A, items: [it({ est_days_remaining: 6 }), it({ quantity: 3, est_days_remaining: 2, freshness: 'use_soon' })] }, TODAY);
  assert.equal(out.length, 1);
  assert.equal(out[0].quantity, 5);
  assert.equal(out[0].freshness, 'use_soon');
});

test('interpret: spoiled and low-confidence items are flagged', () => {
  const [a, b] = interpret({ assessment: A, items: [it({ name: 'spinach', freshness: 'spoiled' }), it({ name: 'jar', confidence: 0.3 })] }, TODAY);
  assert.equal(a.spoiled, true);
  assert.equal(b.needs_review, true);
});

test('interpret rejects people, inappropriate, not-food, unusable and empty scenes', () => {
  for (const [patch, code] of [[{ contains_people: true }, 'image_has_people'], [{ inappropriate_content: true }, 'image_rejected'], [{ is_food_scene: false }, 'not_food'], [{ image_quality: 'unusable' }, 'image_unusable']]) {
    assert.throws(() => interpret({ assessment: { ...A, ...patch }, items: [it()] }, TODAY), (e) => e.code === code);
  }
  assert.throws(() => interpret({ assessment: A, items: [] }, TODAY), (e) => e.code === 'no_items_found');
});

test('rate limiter blocks after max and sets Retry-After', () => {
  const mw = rateLimit({ windowMs: 60_000, max: 2, key: () => 'k' });
  const res = { setHeader() {} };
  const results = [];
  for (let i = 0; i < 3; i++) mw({}, res, (err) => results.push(err));
  assert.equal(results[0], undefined);
  assert.equal(results[1], undefined);
  assert.ok(results[2]);
  assert.equal(results[2].status, 429);
});
