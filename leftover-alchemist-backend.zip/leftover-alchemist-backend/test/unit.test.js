'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { s, validate, toJsonSchema } = require('../src/lib/validate');
const units = require('../src/lib/units');
const { normalizeName, findPantryMatch } = require('../src/lib/names');
const dates = require('../src/lib/dates');
const shelf = require('../src/lib/shelfLife');
const { checkRecipeSafety, flagItem } = require('../src/lib/allergens');
const { scaleIngredients, evaluateIngredients, isMissing } = require('../src/lib/scaling');

test('validate: strips unknowns, cleans text, reports errors', () => {
  const schema = s.object({
    name: s.string({ min: 1, max: 10 }),
    qty: s.number({ min: 0 }).default(1),
    tags: s.array(s.string({ max: 5 }), { max: 2 }).optional(),
  });
  const ok = validate(schema, { name: '  hi\u0000 ‮there  ', extra: 1 });
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.value, { name: 'hi there', qty: 1 });
  const bad = validate(schema, { name: '', tags: ['a', 'b', 'c'] });
  assert.equal(bad.ok, false);
  assert.ok(bad.errors.some((e) => e.path === 'name'));
  assert.ok(bad.errors.some((e) => e.path === 'tags'));
});

test('validate: toJsonSchema marks required/nullable correctly', () => {
  const js = toJsonSchema(s.object({ a: s.string(), b: s.integer({ min: 1, max: 3 }).nullable(), c: s.enum(['x']).optional() }));
  assert.deepEqual(js.required, ['a', 'b']);
  assert.equal(js.additionalProperties, false);
  assert.deepEqual(js.properties.b.anyOf[1], { type: 'null' });
  assert.equal(js.properties.b.anyOf[0].maximum, 3);
});

test('units: conversion, aliases, incompatible dims', () => {
  assert.equal(units.normalizeUnit('Grams'), 'g');
  assert.equal(units.normalizeUnit('tins'), 'can');
  assert.equal(units.normalizeUnit('weird'), 'count');
  assert.equal(units.convert(1, 'kg', 'g'), 1000);
  assert.ok(Math.abs(units.convert(3, 'tsp', 'tbsp') - 1) < 0.01);
  assert.equal(units.convert(100, 'g', 'ml'), null);
  assert.equal(units.convert(2, 'count', 'pack'), null);
});

test('units: display rounds sensibly and upgrades units', () => {
  assert.equal(units.displayAmount(1500, 'g').display, '1.5 kg');
  assert.equal(units.displayAmount(250, 'ml').display, '250 ml');
  assert.equal(units.displayAmount(0.5, 'cup').display, '½ cup');
  assert.equal(units.displayAmount(1.5, 'count').display, '1 ½');
  assert.equal(units.displayAmount(6, 'tsp').display, '2 tbsp');
  assert.equal(units.displayAmount(0, 'g').display, 'to taste');
});

test('names: normalisation and matching never match the dangerous direction', () => {
  assert.equal(normalizeName('Fresh Tomatoes'), 'tomato');
  assert.equal(normalizeName('Hummus'), 'hummus');
  assert.equal(normalizeName('Cherry tomatoes (ripe)'), 'cherry tomato');
  const pantry = [
    { id: 1, normalized_name: 'cherry tomato', expires_on: '2026-10-12' },
    { id: 2, normalized_name: 'butter', expires_on: '2026-10-20' },
  ];
  assert.equal(findPantryMatch('tomato', pantry).id, 1);
  assert.equal(findPantryMatch('peanut butter', pantry), null); // recipe is more specific than pantry
  assert.equal(findPantryMatch('butter', pantry).id, 2);
});

test('dates: local date honours timezone, day arithmetic', () => {
  const t = new Date('2026-10-10T23:30:00Z');
  assert.equal(dates.localDate('UTC', t), '2026-10-10');
  assert.equal(dates.localDate('Pacific/Auckland', t), '2026-10-11');
  assert.equal(dates.addDays('2026-02-27', 2), '2026-03-01');
  assert.equal(dates.daysBetween('2026-10-10', '2026-10-13'), 3);
  assert.equal(dates.isValidYmd('2026-02-30'), false);
  assert.equal(dates.monthBounds(new Date('2026-02-10T00:00:00Z')).end, '2026-02-28');
});

test('shelf life: label wins, model guess clamped, spoiled is expired', () => {
  const today = '2026-10-10';
  assert.deepEqual(shelf.estimateExpiry({ category: 'dairy', labelDate: '2026-10-15', today }),
    { expiresOn: '2026-10-15', source: 'label', daysLeft: 5 });
  // model says 60 days for raw chicken: clamped to category max (3)
  assert.equal(shelf.estimateExpiry({ category: 'meat', freshness: 'fresh', modelDays: 60, today }).daysLeft, 3);
  // past_prime ceiling
  assert.ok(shelf.estimateExpiry({ category: 'produce', freshness: 'past_prime', modelDays: 6, today }).daysLeft <= 2);
  assert.equal(shelf.estimateExpiry({ category: 'produce', freshness: 'spoiled', modelDays: 6, today }).daysLeft, -1);
  // absurd label date (year 2099) is ignored
  assert.equal(shelf.estimateExpiry({ category: 'dairy', labelDate: '2099-01-01', freshness: 'fresh', today }).source, 'estimated');
  assert.equal(shelf.guessCategory('Peanut butter'), 'condiment');
  assert.equal(shelf.guessCategory('whole milk'), 'dairy');
  assert.ok(shelf.estimateValueCents('meat', 500, 'g') > 400);
});

const prefs = (o) => ({ allergies: [], diets: [], disliked_ingredients: [], ...o });
const recipe = (names, steps = ['Cook it.']) => ({ title: 'Test', ingredients: names.map((n) => ({ name: n })), steps });

test('allergens: catches obvious and derived sources', () => {
  assert.equal(checkRecipeSafety(recipe(['peanut butter']), prefs({ allergies: ['peanut'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['butter']), prefs({ allergies: ['dairy'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['mayonnaise']), prefs({ allergies: ['egg'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['soy sauce']), prefs({ allergies: ['gluten'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['oyster sauce']), prefs({ allergies: ['shellfish'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['hummus']), prefs({ allergies: ['sesame'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['rice'], ['Stir in the cream at the end.']), prefs({ allergies: ['milk'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['kiwi']), prefs({ allergies: ['Kiwi'] })).ok, false); // custom allergen
  assert.equal(checkRecipeSafety(recipe(['almonds']), prefs({ allergies: ['nuts'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['walnut']), prefs({ allergies: ['tree nut'] })).ok, false);
});

test('allergens: does not over-flag common safe look-alikes', () => {
  const dairy = prefs({ allergies: ['dairy'] });
  for (const n of ['peanut butter', 'almond milk', 'coconut milk', 'cocoa butter', 'butternut squash', 'cream of tartar', 'oat milk']) {
    assert.equal(checkRecipeSafety(recipe([n]), dairy).ok, true, n);
  }
  assert.equal(checkRecipeSafety(recipe(['eggplant']), prefs({ allergies: ['egg'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['nutmeg', 'coconut', 'butternut squash']), prefs({ allergies: ['nuts'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['rice noodles', 'rice flour']), prefs({ allergies: ['gluten'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['rice'], ['Wrap in foil and bake in a cake tin.']), prefs({ allergies: ['gluten'] })).ok, true);
});

test('diets: vegetarian, vegan, halal, kosher mixing', () => {
  assert.equal(checkRecipeSafety(recipe(['chicken breast']), prefs({ diets: ['vegetarian'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['worcestershire sauce']), prefs({ diets: ['vegetarian'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['tofu', 'veggie burger']), prefs({ diets: ['vegetarian'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['honey']), prefs({ diets: ['vegan'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['egg']), prefs({ diets: ['vegan'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['salmon']), prefs({ diets: ['pescatarian'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['white wine']), prefs({ diets: ['halal'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['white wine vinegar']), prefs({ diets: ['halal'] })).ok, true);
  assert.equal(checkRecipeSafety(recipe(['beef mince', 'cheddar']), prefs({ diets: ['kosher'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['bread']), prefs({ diets: ['gluten_free'] })).ok, false);
});

test('allergens: dislikes, unsafe items and warnings', () => {
  assert.equal(checkRecipeSafety(recipe(['cilantro']), prefs({ disliked_ingredients: ['Cilantro'] })).ok, false);
  assert.equal(checkRecipeSafety(recipe(['bleach']), prefs()).ok, false);
  const w = checkRecipeSafety(recipe(['chicken stock', 'chicken thigh']), prefs({ allergies: ['peanut'] }));
  assert.ok(w.warnings.length >= 2); // hidden-allergen label warning + cook-through warning
  assert.deepEqual(flagItem('Peanut butter', prefs({ allergies: ['peanut'] })), ['contains peanut']);
});

test('scaling: scales, rounds, leaves to-taste alone; evaluation finds shortfalls', () => {
  const base = [
    { name: 'rice', amount: 200, unit: 'g', pantry_item_id: 1 },
    { name: 'egg', amount: 2, unit: 'count', pantry_item_id: 2 },
    { name: 'soy sauce', amount: 0, unit: 'to_taste' },
    { name: 'salt', amount: 1, unit: 'tsp' },
  ];
  const scaled = scaleIngredients(base, 2, 5);
  assert.equal(scaled[0].display, '500 g');
  assert.equal(scaled[1].display, '5');
  assert.equal(scaled[2].display, 'to taste');
  const pantry = [
    { id: 1, name: 'Rice', normalized_name: 'rice', quantity: 300, unit: 'g', is_staple: false },
    { id: 2, name: 'Eggs', normalized_name: 'egg', quantity: 4, unit: 'count', is_staple: false },
  ];
  const ev = evaluateIngredients(base, pantry, 5 / 2);
  assert.equal(ev[0].status, 'partial');
  assert.equal(Math.round(ev[0].shortfall.amount), 200); // need 500, have 300
  assert.equal(ev[1].status, 'partial');
  assert.equal(ev[1].shortfall.amount, 1);
  assert.equal(ev[2].status, 'missing');
  assert.equal(ev[3].status, 'assumed'); // salt is always assumed
  assert.equal(ev.filter(isMissing).length, 3);
});
