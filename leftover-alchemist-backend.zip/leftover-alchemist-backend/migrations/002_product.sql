-- Leftover Alchemist: product schema (builds on 001_init.sql)

-- ---------- users & sessions ----------
ALTER TABLE users
  ADD COLUMN timezone TEXT NOT NULL DEFAULT 'UTC',
  ADD COLUMN currency TEXT NOT NULL DEFAULT 'EUR',
  ADD CONSTRAINT users_email_lower CHECK (email = lower(email));

-- Opaque random session tokens. Only a SHA-256 hash is stored, so a database leak
-- does not leak usable tokens, and sessions can be revoked (logout) server-side.
CREATE TABLE sessions (
  token_hash    TEXT PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at    TIMESTAMPTZ NOT NULL,
  last_used_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_user ON sessions(user_id);
CREATE INDEX idx_sessions_expires ON sessions(expires_at);

-- ---------- photos ----------
-- Image bytes (resized, EXIF-stripped JPEG) live in the database for the MVP: private by
-- construction, transactional, deleted with the account. Swap for S3 later if needed.
ALTER TABLE photos
  ALTER COLUMN image_url DROP NOT NULL,
  ADD COLUMN image_data BYTEA,
  ADD COLUMN mime_type TEXT,
  ADD COLUMN bytes INTEGER,
  ADD COLUMN width INTEGER,
  ADD COLUMN height INTEGER,
  ADD COLUMN sha256 TEXT,
  ADD COLUMN status TEXT NOT NULL DEFAULT 'uploaded'
    CHECK (status IN ('uploaded', 'analyzing', 'analyzed', 'confirmed', 'failed', 'rejected')),
  ADD COLUMN failure_code TEXT,
  ADD COLUMN assessment JSONB,
  ADD COLUMN model TEXT,
  ADD COLUMN quota_period_start DATE,
  ADD COLUMN analyzed_at TIMESTAMPTZ;
CREATE INDEX idx_photos_user_sha ON photos(user_id, sha256);

-- ---------- preferences ----------
CREATE TABLE user_preferences (
  user_id              INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  allergies            TEXT[] NOT NULL DEFAULT '{}',
  diets                TEXT[] NOT NULL DEFAULT '{}',
  disliked_ingredients TEXT[] NOT NULL DEFAULT '{}',
  household_size       INTEGER NOT NULL DEFAULT 2 CHECK (household_size BETWEEN 1 AND 20),
  default_max_minutes  INTEGER NOT NULL DEFAULT 30 CHECK (default_max_minutes BETWEEN 5 AND 480),
  skill_level          TEXT NOT NULL DEFAULT 'intermediate' CHECK (skill_level IN ('beginner', 'intermediate', 'advanced')),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- pantry ----------
CREATE TABLE pantry_items (
  id               SERIAL PRIMARY KEY,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  normalized_name  TEXT NOT NULL,
  category         TEXT NOT NULL DEFAULT 'other',
  storage          TEXT NOT NULL DEFAULT 'unknown',
  quantity         NUMERIC(12,3) NOT NULL DEFAULT 1 CHECK (quantity >= 0),
  unit             TEXT NOT NULL DEFAULT 'count',
  is_staple        BOOLEAN NOT NULL DEFAULT FALSE,
  freshness        TEXT NOT NULL DEFAULT 'unknown',
  expires_on       DATE,
  expiry_source    TEXT NOT NULL DEFAULT 'estimated' CHECK (expiry_source IN ('estimated', 'label', 'user')),
  est_value_cents  INTEGER NOT NULL DEFAULT 0 CHECK (est_value_cents >= 0),
  source_photo_id  INTEGER REFERENCES photos(id) ON DELETE SET NULL,
  status           TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'used', 'discarded')),
  added_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_pantry_active ON pantry_items(user_id, normalized_name, unit) WHERE status = 'active';
CREATE INDEX idx_pantry_user_status ON pantry_items(user_id, status, expires_on);

-- carry over anything saved in the old staples table, then retire it
INSERT INTO pantry_items (user_id, name, normalized_name, category, quantity, unit, is_staple)
SELECT user_id, name, lower(trim(name)), 'condiment', 1, 'count', TRUE FROM pantry_staples
ON CONFLICT DO NOTHING;
DROP TABLE pantry_staples;

-- ---------- recipes ----------
ALTER TABLE recipes
  ADD COLUMN description TEXT,
  ADD COLUMN servings INTEGER NOT NULL DEFAULT 2,
  ADD COLUMN difficulty TEXT,
  ADD COLUMN safety JSONB NOT NULL DEFAULT '{}',
  ADD COLUMN params JSONB NOT NULL DEFAULT '{}',
  ADD COLUMN model TEXT,
  ADD COLUMN request_hash TEXT,
  ADD COLUMN status TEXT NOT NULL DEFAULT 'suggested' CHECK (status IN ('suggested', 'saved', 'cooked', 'dismissed')),
  ADD COLUMN cooked_at TIMESTAMPTZ,
  ADD COLUMN cooked_servings INTEGER;
CREATE INDEX idx_recipes_user_hash ON recipes(user_id, request_hash, created_at);

-- ---------- shopping list ----------
CREATE TABLE shopping_list_items (
  id               SERIAL PRIMARY KEY,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  normalized_name  TEXT NOT NULL,
  quantity         NUMERIC(12,3) NOT NULL DEFAULT 1 CHECK (quantity >= 0),
  unit             TEXT NOT NULL DEFAULT 'count',
  category         TEXT NOT NULL DEFAULT 'other',
  checked          BOOLEAN NOT NULL DEFAULT FALSE,
  recipe_id        INTEGER REFERENCES recipes(id) ON DELETE SET NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_shopping_user ON shopping_list_items(user_id, checked);

-- ---------- streaks & savings ----------
CREATE TABLE user_stats (
  user_id             INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  current_streak      INTEGER NOT NULL DEFAULT 0,
  longest_streak      INTEGER NOT NULL DEFAULT 0,
  last_activity_date  DATE,
  total_saved_cents   INTEGER NOT NULL DEFAULT 0,
  items_rescued       INTEGER NOT NULL DEFAULT 0,
  meals_cooked        INTEGER NOT NULL DEFAULT 0,
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE savings_events (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  pantry_item_id INTEGER REFERENCES pantry_items(id) ON DELETE SET NULL,
  recipe_id      INTEGER REFERENCES recipes(id) ON DELETE SET NULL,
  item_name      TEXT NOT NULL,
  amount_cents   INTEGER NOT NULL CHECK (amount_cents >= 0),
  days_to_expiry INTEGER,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_savings_user ON savings_events(user_id, created_at);

-- ---------- AI metering ----------
-- One row per logical AI call (including its retries). Drives per-user and global budgets.
-- user_id is SET NULL on account deletion so cost accounting survives without personal data.
CREATE TABLE ai_usage (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
  kind           TEXT NOT NULL,
  model          TEXT NOT NULL,
  input_tokens   INTEGER NOT NULL DEFAULT 0,
  output_tokens  INTEGER NOT NULL DEFAULT 0,
  cost_micros    BIGINT NOT NULL DEFAULT 0,
  status         TEXT NOT NULL CHECK (status IN ('ok', 'error')),
  attempts       INTEGER NOT NULL DEFAULT 1,
  latency_ms     INTEGER,
  error          TEXT,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ai_usage_user_created ON ai_usage(user_id, created_at);
CREATE INDEX idx_ai_usage_created ON ai_usage(created_at);
