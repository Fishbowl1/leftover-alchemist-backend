-- Leftover Alchemist — initial schema
-- Run with: psql $DATABASE_URL -f migrations/001_init.sql

CREATE TABLE users (
  id                  SERIAL PRIMARY KEY,
  email               TEXT UNIQUE NOT NULL,
  password_hash       TEXT NOT NULL,
  plan                TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'paid')),
  stripe_customer_id  TEXT,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE usage_periods (
  id            SERIAL PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period_start  DATE NOT NULL,
  period_end    DATE NOT NULL,
  photos_used   INTEGER NOT NULL DEFAULT 0,
  UNIQUE (user_id, period_start)
);

CREATE TABLE photos (
  id              SERIAL PRIMARY KEY,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  image_url       TEXT NOT NULL,
  detected_items  JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE recipes (
  id            SERIAL PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  photo_id      INTEGER REFERENCES photos(id) ON DELETE SET NULL,
  title         TEXT NOT NULL,
  ingredients   JSONB NOT NULL,
  steps         JSONB NOT NULL,
  time_minutes  INTEGER,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE pantry_staples (
  id        SERIAL PRIMARY KEY,
  user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name      TEXT NOT NULL,
  added_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Every time a free user hits the photo cap, log it.
-- This is the data set you'll use to decide whether 3/month is the right number.
CREATE TABLE paywall_events (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  trigger     TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_usage_periods_user ON usage_periods(user_id);
CREATE INDEX idx_photos_user ON photos(user_id);
CREATE INDEX idx_recipes_user ON recipes(user_id);
CREATE INDEX idx_pantry_staples_user ON pantry_staples(user_id);
CREATE INDEX idx_paywall_events_user ON paywall_events(user_id);
