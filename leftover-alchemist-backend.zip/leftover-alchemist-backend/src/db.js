'use strict';
const { Pool } = require('pg');
const config = require('./config');
const { log } = require('./errors');

let pool = null;

function getPool() {
  if (!pool) {
    if (!config.databaseUrl) throw new Error('DATABASE_URL is not set. See README.md → Setup.');
    pool = new Pool({
      connectionString: config.databaseUrl,
      max: config.dbPoolMax,
      ssl: config.databaseSsl ? { rejectUnauthorized: false } : undefined,
      idleTimeoutMillis: 30_000,
      connectionTimeoutMillis: 10_000,
    });
    pool.on('error', (err) => log.error('postgres pool error', { err }));
  }
  return pool;
}

const query = (text, params) => getPool().query(text, params);

// Runs fn(client) inside a transaction. Inside fn, use ONLY the `client` you are given.
async function withTransaction(fn) {
  const client = await getPool().connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch { /* connection already broken */ }
    throw err;
  } finally {
    client.release();
  }
}

async function close() {
  if (pool) { await pool.end(); pool = null; }
}

module.exports = { query, withTransaction, getPool, close };
