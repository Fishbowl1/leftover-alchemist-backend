'use strict';
const express = require('express');
const config = require('./config');
const db = require('./db');
const { requestContext, securityHeaders, rateLimit, asyncHandler, notFound, errorHandler } = require('./middleware/common');
const { authRouter, meRouter } = require('./routes/account');
const photosRouter = require('./routes/photos');
const pantryRouter = require('./routes/pantry');
const { recipeRouter, shoppingRouter, statsRouter } = require('./routes/recipes');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);

  app.use(requestContext);
  app.use(securityHeaders);
  app.use(rateLimit({ windowMs: 60_000, max: config.rate.globalPerMin }));

  app.get('/health', (req, res) => res.json({ ok: true }));
  app.get('/health/ready', asyncHandler(async (req, res) => {
    await db.query('SELECT 1');
    res.json({ ok: true, database: true, aiConfigured: Boolean(config.ai.apiKey) });
  }));

  app.use(express.json({ limit: 100 * 1024 }));
  app.use('/auth', authRouter);
  app.use('/me', meRouter);
  app.use('/photos', photosRouter);
  app.use('/pantry', pantryRouter);
  app.use('/recipes', recipeRouter);
  app.use('/shopping-list', shoppingRouter);
  app.use('/stats', statsRouter);

  app.use(notFound);
  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
