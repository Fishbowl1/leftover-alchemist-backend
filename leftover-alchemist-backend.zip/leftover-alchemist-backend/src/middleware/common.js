'use strict';
const crypto = require('crypto');
const config = require('../config');
const auth = require('../services/auth');
const { E, AppError, log } = require('../errors');
const { validate } = require('../lib/validate');

const asyncHandler = (fn) => (req, res, next) => { Promise.resolve(fn(req, res, next)).catch(next); };

function requestContext(req, res, next) {
  req.id = crypto.randomUUID();
  res.setHeader('X-Request-Id', req.id);
  const start = Date.now();
  res.on('finish', () => log.info('request', {
    id: req.id, method: req.method, path: (req.originalUrl || req.url).split('?')[0],
    status: res.statusCode, ms: Date.now() - start, user: req.user ? req.user.id : undefined,
  }));
  next();
}

function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
  res.setHeader('Cache-Control', 'no-store');
  if (config.isProd) res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  next();
}

const requireAuth = asyncHandler(async (req, res, next) => {
  const m = /^Bearer ([A-Za-z0-9_-]{20,200})$/.exec(req.headers.authorization || '');
  if (!m) throw E.unauthorized();
  const user = await auth.authenticate(m[1]);
  if (!user) throw E.unauthorized('Your session has expired. Please sign in again.');
  req.user = user;
  req.token = m[1];
  next();
});

// Fixed-window in-memory limiter. Fine for one server instance; use a shared store
// (e.g. Redis) once you run several instances.
function rateLimit({ windowMs, max, key = (req) => req.ip, message }) {
  const hits = new Map();
  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of hits) if (v.reset <= now) hits.delete(k);
  }, 60_000);
  sweep.unref();
  return (req, res, next) => {
    const k = String(key(req));
    const now = Date.now();
    let e = hits.get(k);
    if (!e || e.reset <= now) { e = { count: 0, reset: now + windowMs }; hits.set(k, e); }
    e.count += 1;
    res.setHeader('RateLimit-Limit', String(max));
    res.setHeader('RateLimit-Remaining', String(Math.max(0, max - e.count)));
    if (e.count > max) {
      res.setHeader('Retry-After', String(Math.ceil((e.reset - now) / 1000)));
      return next(E.tooMany('rate_limited', message || 'Too many requests. Please slow down and try again shortly.'));
    }
    return next();
  };
}

// Validate request data against a schema or throw a 400 with field-level details.
function parse(schema, data) {
  const r = validate(schema, data);
  if (!r.ok) throw E.badRequest('validation_error', 'Some fields are missing or invalid.', r.errors);
  return r.value;
}

function notFound(req, res, next) { next(new AppError(404, 'not_found', 'That endpoint does not exist.')); }

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let status = 500;
  let body = { code: 'internal_error', message: 'Something went wrong on our side. Please try again.' };
  if (err instanceof AppError) {
    status = err.status;
    body = { code: err.code, message: err.message, ...(err.details ? { details: err.details } : {}) };
  } else if (err && err.type === 'entity.too.large') {
    status = 413; body = { code: 'payload_too_large', message: 'That upload is too large.' };
  } else if (err && err.type === 'entity.parse.failed') {
    status = 400; body = { code: 'invalid_json', message: 'The request body is not valid JSON.' };
  } else if (err && err.code === '23505') {
    status = 409; body = { code: 'conflict', message: 'That conflicts with something that already exists. Please try again.' };
  } else if (err && err.code === '22P02') {
    status = 400; body = { code: 'invalid_input', message: 'One of the values has an invalid format.' };
  } else {
    log.error('unhandled error', { err, id: req.id, path: (req.originalUrl || req.url || '').split('?')[0] });
  }
  if (res.headersSent) return;
  res.status(status).json({ error: { ...body, requestId: req.id } });
}

module.exports = { asyncHandler, requestContext, securityHeaders, requireAuth, rateLimit, parse, notFound, errorHandler };
