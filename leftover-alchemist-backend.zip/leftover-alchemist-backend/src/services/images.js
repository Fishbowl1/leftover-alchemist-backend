'use strict';
// Image validation + sanitising. Every upload is fully DECODED (so a renamed .exe or a
// decompression bomb is rejected), auto-rotated, downscaled (this also caps vision cost),
// and re-encoded as JPEG, which drops all metadata including GPS location and camera info.
const crypto = require('crypto');
const config = require('../config');
const { AppError, E } = require('../errors');

let sharpLib = null;
function getSharp() {
  if (!sharpLib) {
    try { sharpLib = require('sharp'); } catch { throw new AppError(500, 'image_processing_unavailable', 'Image processing is not installed on this server.'); }
  }
  return sharpLib;
}

const ALLOWED = new Set(['jpeg', 'png', 'webp']);

async function prepareImage(input) {
  if (!Buffer.isBuffer(input) || input.length < 100) throw E.badRequest('invalid_image', 'That file does not look like an image.');
  const sharp = getSharp();
  let meta;
  try {
    meta = await sharp(input, { limitInputPixels: config.upload.maxInputPixels, failOn: 'error' }).metadata();
  } catch {
    throw E.badRequest('invalid_image', 'We could not read that image. Please try another photo.');
  }
  if (!ALLOWED.has(meta.format)) throw E.badRequest('unsupported_image_type', 'Please upload a JPEG, PNG or WebP image.');
  try {
    const { data, info } = await sharp(input, { limitInputPixels: config.upload.maxInputPixels, failOn: 'error' })
      .rotate()
      .resize({ width: config.upload.maxEdge, height: config.upload.maxEdge, fit: 'inside', withoutEnlargement: true })
      .flatten({ background: '#ffffff' })
      .jpeg({ quality: config.upload.jpegQuality })
      .toBuffer({ resolveWithObject: true });
    return { buffer: data, width: info.width, height: info.height, mime: 'image/jpeg', sha256: crypto.createHash('sha256').update(data).digest('hex') };
  } catch {
    throw E.badRequest('invalid_image', 'We could not process that image. Please try another photo.');
  }
}

module.exports = { prepareImage };
