'use strict';
// Shopping list: add by hand or from a recipe (only what's actually missing, scaled to the
// chosen servings), tick items off, then "purchase" to move them into the pantry.
const db = require('../db');
const { E } = require('../errors');
const { localDate } = require('../lib/dates');
const { normalizeName } = require('../lib/names');
const { normalizeUnit, convert, displayAmount } = require('../lib/units');
const { guessCategory, CATEGORIES } = require('../lib/shelfLife');
const { evaluateIngredients, isMissing } = require('../lib/scaling');
const pantry = require('./pantry');
const recipes = require('./recipeService');

const COLS = 'id, name, normalized_name, quantity::float8 AS quantity, unit, category, checked, recipe_id, created_at';
const round3 = (n) => Math.round(n * 1000) / 1000;

function present(r) {
  const d = displayAmount(r.quantity, r.unit);
  return { id: r.id, name: r.name, quantity: d.amount, unit: d.unit, display: d.display, category: r.category, checked: r.checked, recipeId: r.recipe_id };
}

async function list(userId, client = db) {
  const r = await client.query(`SELECT ${COLS} FROM shopping_list_items WHERE user_id = $1 ORDER BY checked, category, name`, [userId]);
  return r.rows;
}

// Adds to an existing unticked line for the same thing (when units are compatible) instead of duplicating it.
async function addLine(client, userId, { name, quantity, unit, category, recipeId }) {
  const normalized = normalizeName(name);
  if (!normalized) throw E.badRequest('invalid_name', 'Please give the item a name.');
  const u = normalizeUnit(unit);
  const q = round3(quantity);
  if (!(q > 0)) throw E.badRequest('invalid_quantity', 'Quantity must be more than zero.');
  const existing = (await client.query(
    `SELECT ${COLS} FROM shopping_list_items WHERE user_id = $1 AND normalized_name = $2 AND checked = FALSE FOR UPDATE`, [userId, normalized])).rows;
  const target = existing.find((e) => e.unit === u) || existing.find((e) => convert(1, u, e.unit) !== null);
  if (target) {
    const r = await client.query(
      `UPDATE shopping_list_items SET quantity = $2 WHERE id = $1 RETURNING ${COLS}`,
      [target.id, round3(target.quantity + convert(q, u, target.unit))]);
    return r.rows[0];
  }
  const r = await client.query(
    `INSERT INTO shopping_list_items (user_id, name, normalized_name, quantity, unit, category, recipe_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING ${COLS}`,
    [userId, String(name).trim().slice(0, 80), normalized, q, u, CATEGORIES.includes(category) ? category : guessCategory(name), recipeId || null]);
  return r.rows[0];
}

async function addItem(userId, input) {
  return present(await addLine(db, userId, input));
}

// Adds ONLY what the recipe needs beyond what is already in the pantry, at the chosen servings.
async function addFromRecipe(user, recipeId, servings) {
  const today = localDate(user.timezone);
  const row = await recipes.loadRow(user.id, recipeId);
  const target = servings || row.servings;
  const factor = target / row.servings;
  const { usable } = await recipes.usablePantry(user.id, today);
  const needs = evaluateIngredients(row.ingredients, usable, factor).filter(isMissing);
  const added = await db.withTransaction(async (c) => {
    const out = [];
    for (const n of needs) {
      const amount = n.shortfall ? n.shortfall.amount : 1; // unspecified ("to taste") amounts: buy one
      const unit = n.shortfall ? n.shortfall.unit : 'count';
      out.push(await addLine(c, user.id, { name: n.name, quantity: amount, unit, recipeId }));
    }
    return out;
  });
  return { added: added.map(present), nothingNeeded: needs.length === 0 };
}

async function updateItem(userId, id, patch) {
  const sets = []; const vals = [id, userId];
  if (patch.checked !== undefined) { vals.push(patch.checked); sets.push(`checked = $${vals.length}`); }
  if (patch.quantity !== undefined) { vals.push(round3(patch.quantity)); sets.push(`quantity = $${vals.length}`); }
  if (!sets.length) throw E.badRequest('nothing_to_update', 'Nothing to change.');
  const r = await db.query(`UPDATE shopping_list_items SET ${sets.join(', ')} WHERE id = $1 AND user_id = $2 RETURNING ${COLS}`, vals);
  if (!r.rows[0]) throw E.notFound('Shopping item');
  return present(r.rows[0]);
}

async function removeItem(userId, id) {
  const r = await db.query('DELETE FROM shopping_list_items WHERE id = $1 AND user_id = $2', [id, userId]);
  if (!r.rowCount) throw E.notFound('Shopping item');
}

async function clearChecked(userId) {
  const r = await db.query('DELETE FROM shopping_list_items WHERE user_id = $1 AND checked = TRUE', [userId]);
  return r.rowCount;
}

// "I bought these": ticked items move into the pantry (merging with what's there) and leave the list.
async function purchase(user) {
  const today = localDate(user.timezone);
  return db.withTransaction(async (c) => {
    const rows = (await c.query(`SELECT ${COLS} FROM shopping_list_items WHERE user_id = $1 AND checked = TRUE FOR UPDATE`, [user.id])).rows;
    const items = [];
    for (const r of rows) {
      const { item } = await pantry.addOrMerge(c, user.id, { name: r.name, quantity: r.quantity, unit: r.unit, category: r.category, freshness: 'fresh' }, today);
      items.push(pantry.present(item, today));
    }
    await c.query('DELETE FROM shopping_list_items WHERE user_id = $1 AND checked = TRUE', [user.id]);
    return { moved: items.length, pantryItems: items };
  });
}

module.exports = { list, present, addItem, addFromRecipe, updateItem, removeItem, clearChecked, purchase };
