'use strict';
// Recipe generation with ENFORCED constraints, plus view/scale/cook.
//
// The model drafts; this module verifies. A draft is accepted only if it (1) passes the
// deterministic allergy/diet/dislike screen, (2) uses at most N non-pantry ingredients,
// (3) doesn't exceed pantry quantities, (4) includes any must-use items and (5) fits the
// time limit. Otherwise the problems are fed back and the model tries again (bounded).
const crypto = require('crypto');
const db = require('../db');
const config = require('../config');
const { E, log } = require('../errors');
const { localDate, daysBetween } = require('../lib/dates');
const { s } = require('../lib/validate');
const { convert, displayAmount } = require('../lib/units');
const { checkRecipeSafety, DISCLAIMER } = require('../lib/allergens');
const { scaleIngredients, timeNote, evaluateIngredients, isMissing } = require('../lib/scaling');
const preferences = require('./preferences');
const pantry = require('./pantry');
const stats = require('./stats');
const aiRecipes = require('../ai/recipes');

const COLS = `id, title, description, ingredients, steps, time_minutes, servings, difficulty, safety, params, model,
  status, created_at, cooked_at, cooked_servings`;

const GENERATE = s.object({
  servings: s.integer({ min: 1, max: 20 }).optional(),
  maxMinutes: s.integer({ min: 5, max: 480 }).optional(),
  maxMissing: s.integer({ min: 0, max: 5 }).optional(),
  mustUseItemIds: s.array(s.integer({ min: 1 }), { max: 10 }).optional(),
  avoidTitles: s.array(s.string({ max: 100 }), { max: 10 }).optional(),
  refresh: s.boolean().optional(),
});

const round3 = (n) => Math.round(n * 1000) / 1000;

// Turn a model draft into stored "base" ingredients (at the requested servings) with
// every pantry link re-verified by us rather than trusted from the model.
function buildBase(data, cookable, targetServings) {
  let base = data.ingredients.map((i) => ({
    name: i.name, amount: i.unit === 'to_taste' ? 0 : i.amount, unit: i.unit,
    pantry_item_id: i.pantry_item_id ?? null, optional: i.optional, note: i.note || null,
  }));
  if (data.servings !== targetServings) {
    base = scaleIngredients(base, data.servings, targetServings)
      .map(({ exact, display, displayUnit, ...rest }) => ({ ...rest, amount: round3(exact) }));
  }
  const evald = evaluateIngredients(base, cookable, 1);
  base = base.map((b, i) => ({ ...b, pantry_item_id: evald[i].pantryItem ? evald[i].pantryItem.id : null }));
  return { base, evald };
}

function verify({ data, base, evald, prefs, p, cookable }) {
  const problems = [];
  const safety = checkRecipeSafety({ title: data.title, description: data.description, ingredients: base, steps: data.steps }, prefs);
  for (const v of safety.violations) {
    if (v.kind === 'allergen') problems.push(`Contains "${v.matched}", which conflicts with the allergy "${v.restriction}" (${v.where}). Remove it and anything derived from it.`);
    else if (v.kind === 'diet') problems.push(`Contains "${v.matched}", which is not ${v.label} (${v.where}).`);
    else if (v.kind === 'dislike') problems.push(`Uses "${v.matched}", which the person dislikes (${v.where}).`);
    else problems.push(`Contains a non-food item "${v.matched}".`);
  }
  const missing = evald.filter(isMissing);
  if (missing.length > p.maxMissing) {
    problems.push(`It needs ${missing.length} ingredients the person does not have enough of (${missing.map((m) => m.name).join(', ')}), but at most ${p.maxMissing} are allowed. Rebuild it around pantry items and quantities.`);
  }
  for (const id of p.mustUseIds) {
    if (!base.some((b) => b.pantry_item_id === id)) {
      const it = cookable.find((c) => c.id === id);
      problems.push(`It must use "${it ? it.name : `pantry item ${id}`}" but does not.`);
    }
  }
  if (data.time_minutes > p.maxMinutes * 1.15) problems.push(`It takes ${data.time_minutes} minutes but the limit is ${p.maxMinutes}.`);
  return { problems, safety, missing };
}

function presentRecipe(row, usableItems, today, servings) {
  const target = servings || row.servings;
  const factor = target / row.servings;
  const scaled = scaleIngredients(row.ingredients, row.servings, target);
  const evald = evaluateIngredients(row.ingredients, usableItems, factor);
  const ingredients = scaled.map((sc, i) => {
    const ev = evald[i];
    const pi = ev.pantryItem;
    const dl = pi && pi.expires_on ? daysBetween(today, pi.expires_on) : null;
    const out = {
      name: sc.name, amount: sc.amount, unit: sc.unit === 'to_taste' ? 'to_taste' : (sc.displayUnit || sc.unit), display: sc.display,
      optional: !!sc.optional, note: sc.note || null, status: ev.status, pantryItemId: pi ? pi.id : null, daysLeft: dl,
      expiringSoon: !!(pi && !pi.is_staple && dl !== null && dl >= 0 && dl <= 3),
    };
    if (ev.shortfall) { const d = displayAmount(ev.shortfall.amount, ev.shortfall.unit); out.shortfall = { amount: d.amount, unit: d.unit, display: d.display }; }
    if (ev.quantityUnverified) out.quantityUnverified = true;
    return out;
  });
  const missing = ingredients.filter((_, i) => isMissing(evald[i]))
    .map((x) => ({ name: x.name, needed: x.shortfall ? x.shortfall.display : x.display, partial: x.status === 'partial' }));
  return {
    id: row.id, title: row.title, description: row.description, servings: target, baseServings: row.servings,
    timeMinutes: row.time_minutes, timeNote: target !== row.servings ? timeNote(row.servings, target) : null,
    difficulty: row.difficulty, status: row.status, ingredients, steps: row.steps, missing,
    usesExpiring: ingredients.filter((x) => x.expiringSoon).map((x) => x.name),
    canCookNow: missing.length === 0,
    safety: { ...row.safety, disclaimer: DISCLAIMER },
    createdAt: row.created_at, cookedAt: row.cooked_at,
  };
}

async function loadRow(userId, id, client = db) {
  const r = await client.query(`SELECT ${COLS} FROM recipes WHERE id = $1 AND user_id = $2`, [id, userId]);
  if (!r.rows[0]) throw E.notFound('Recipe');
  return r.rows[0];
}

async function usablePantry(userId, today, client = db) {
  const items = await pantry.list(userId, { client });
  return pantry.splitUsable(items, today);
}

async function generate(user, input) {
  const today = localDate(user.timezone);
  const prefs = await preferences.get(user.id);
  const { usable: cookable, excluded } = await usablePantry(user.id, today);
  if (!cookable.some((i) => !i.is_staple)) {
    throw E.unprocessable('pantry_empty', excluded.length
      ? 'Everything in your pantry is spoiled or past its date, so we will not suggest cooking it. Scan your fridge again or add fresh items.'
      : 'Your pantry is empty. Scan your fridge or add a few items first.');
  }
  const ids = new Set(cookable.map((i) => i.id));
  const p = {
    servings: input.servings ?? prefs.household_size,
    maxMinutes: input.maxMinutes ?? prefs.default_max_minutes,
    maxMissing: input.maxMissing ?? 2,
    mustUseIds: (input.mustUseItemIds || []).filter((id) => ids.has(id)),
    avoidTitles: input.avoidTitles || [],
  };

  const hash = crypto.createHash('sha256').update(JSON.stringify({
    u: user.id, today, p,
    pantry: cookable.map((i) => [i.id, i.quantity, i.unit, i.expires_on]),
    prefs: [prefs.allergies, prefs.diets, prefs.disliked_ingredients, prefs.skill_level],
  })).digest('hex');

  if (!input.refresh) { // identical request recently? reuse it: no AI cost, instant
    const hit = await db.query(
      `SELECT ${COLS} FROM recipes WHERE user_id = $1 AND request_hash = $2 AND created_at > $3 AND status IN ('suggested', 'saved')
        ORDER BY id DESC LIMIT 1`,
      [user.id, hash, new Date(Date.now() - config.recipe.cacheMinutes * 60_000)],
    );
    if (hit.rows[0]) return { recipe: presentRecipe(hit.rows[0], cookable, today), cached: true, excludedItems: excluded.map((i) => pantry.present(i, today)) };
  }

  let problems = [];
  for (let attempt = 1; attempt <= config.recipe.maxGenerations; attempt++) {
    const { data, model } = await aiRecipes.draft({ user, pantry: cookable, prefs, params: p, problems, today });
    const { base, evald } = buildBase(data, cookable, p.servings);
    const v = verify({ data, base, evald, prefs, p, cookable });
    if (v.problems.length) {
      problems = v.problems;
      log.warn('recipe draft rejected', { attempt, user: user.id, problems: v.problems.length });
      continue;
    }
    const safety = {
      checked: true, allergens: prefs.allergies, diets: prefs.diets, dislikes: prefs.disliked_ingredients,
      warnings: v.safety.warnings, attempts: attempt,
    };
    const ins = await db.query(
      `INSERT INTO recipes (user_id, title, description, ingredients, steps, time_minutes, servings, difficulty, safety, params, model, request_hash, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, 'suggested') RETURNING ${COLS}`,
      [user.id, data.title, data.description || null, JSON.stringify(base), JSON.stringify(data.steps), data.time_minutes,
        p.servings, data.difficulty, JSON.stringify(safety), JSON.stringify(p), model, hash],
    );
    return { recipe: presentRecipe(ins.rows[0], cookable, today), cached: false, excludedItems: excluded.map((i) => pantry.present(i, today)) };
  }
  throw E.unprocessable('no_suitable_recipe',
    'We could not build a recipe that fits your pantry and restrictions this time. Try adding a few more ingredients, or allow one more missing ingredient.',
    { reasons: problems });
}

async function get(user, id, servings) {
  const today = localDate(user.timezone);
  const row = await loadRow(user.id, id);
  const { usable } = await usablePantry(user.id, today);
  return presentRecipe(row, usable, today, servings);
}

async function list(user, status) {
  const today = localDate(user.timezone);
  const r = status
    ? await db.query(`SELECT ${COLS} FROM recipes WHERE user_id = $1 AND status = $2 ORDER BY id DESC LIMIT 50`, [user.id, status])
    : await db.query(`SELECT ${COLS} FROM recipes WHERE user_id = $1 ORDER BY id DESC LIMIT 50`, [user.id]);
  const { usable } = await usablePantry(user.id, today);
  return r.rows.map((row) => presentRecipe(row, usable, today));
}

async function setStatus(user, id, status) {
  const r = await db.query(
    `UPDATE recipes SET status = $3 WHERE id = $1 AND user_id = $2 AND status <> 'cooked' RETURNING id`, [id, user.id, status]);
  if (!r.rows[0]) { await loadRow(user.id, id); throw E.conflict('already_cooked', 'A cooked recipe can no longer be changed.'); }
  return get(user, id);
}

// Cook: deduct what the recipe uses from the pantry, record savings for rescued items,
// advance the streak. All-or-nothing in one transaction.
async function cook(user, id, { servings } = {}) {
  const today = localDate(user.timezone);
  return db.withTransaction(async (c) => {
    const rr = await c.query(`SELECT ${COLS} FROM recipes WHERE id = $1 AND user_id = $2 FOR UPDATE`, [id, user.id]);
    const row = rr.rows[0];
    if (!row) throw E.notFound('Recipe');
    if (row.status === 'cooked') throw E.conflict('already_cooked', 'You already cooked this one. Generate a new recipe to cook again.');

    const target = servings || row.servings;
    const factor = target / row.servings;
    const items = await pantry.list(user.id, { client: c, lock: true });
    const { usable } = pantry.splitUsable(items, today);
    const evald = evaluateIngredients(row.ingredients, usable, factor);

    const updates = []; const unadjusted = []; const rescuedNames = [];
    let savedCents = 0;
    for (const e of evald) {
      const item = e.pantryItem;
      if (e.status === 'assumed' || !item || item.is_staple || e.unit === 'to_taste' || !(e.amount > 0)) continue;
      const need = e.amount * factor;
      const have = convert(item.quantity, item.unit, e.unit);
      if (have === null) { unadjusted.push(item.name); continue; } // can't compare units: leave for the user to adjust
      const used = Math.min(need, have);
      const fraction = have > 0 ? used / have : 1;
      let remaining = item.quantity * (1 - fraction);
      let status = 'active';
      if (remaining < 0.0005 || fraction > 0.97) { remaining = 0; status = 'used'; }
      const valueUsed = Math.round(item.est_value_cents * fraction);
      const dl = item.expires_on ? daysBetween(today, item.expires_on) : null;
      await c.query(
        `UPDATE pantry_items SET quantity = $2, status = $3, est_value_cents = $4, updated_at = now() WHERE id = $1`,
        [item.id, pantry.round3(remaining), status, item.est_value_cents - valueUsed],
      );
      item.quantity = remaining; item.est_value_cents -= valueUsed; // keep in-memory copy right if an item appears twice
      if (dl !== null && dl >= 0 && dl <= 3 && valueUsed > 0) {
        await c.query(
          `INSERT INTO savings_events (user_id, pantry_item_id, recipe_id, item_name, amount_cents, days_to_expiry) VALUES ($1, $2, $3, $4, $5, $6)`,
          [user.id, item.id, id, item.name, valueUsed, dl],
        );
        savedCents += valueUsed; rescuedNames.push(item.name);
      }
      updates.push({ id: item.id, name: item.name, remaining: pantry.round3(remaining), unit: item.unit, status });
    }
    const streak = await stats.recordCook(c, user.id, today, { savedCents, rescued: rescuedNames.length });
    await c.query(`UPDATE recipes SET status = 'cooked', cooked_at = now(), cooked_servings = $2 WHERE id = $1`, [id, target]);
    return { cooked: true, servings: target, pantryUpdates: updates, rescuedItems: rescuedNames, savedCents, streak, needsManualAdjustment: unadjusted };
  });
}

module.exports = { GENERATE, generate, get, list, setStatus, cook, loadRow, presentRecipe, usablePantry, verify, buildBase };
