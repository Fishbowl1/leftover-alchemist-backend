'use strict';
// "Use it up" streaks and money-saved tracking.
//  - A streak day = a day (in the user's timezone) on which they cooked a recipe from their pantry.
//  - Savings accrue when a cooked recipe uses pantry items that were 0-3 days from their date,
//    valued with rough category prices (estimates, not receipts).
const db = require('../db');
const { daysBetween, monthBounds } = require('../lib/dates');
const pantry = require('./pantry');

async function recordCook(c, userId, today, { savedCents, rescued }) {
  await c.query('INSERT INTO user_stats (user_id) VALUES ($1) ON CONFLICT (user_id) DO NOTHING', [userId]);
  const r = await c.query(
    `SELECT current_streak, longest_streak, to_char(last_activity_date, 'YYYY-MM-DD') AS last
       FROM user_stats WHERE user_id = $1 FOR UPDATE`, [userId]);
  const st = r.rows[0];
  let cur = st.current_streak;
  const diff = st.last ? daysBetween(st.last, today) : null;
  if (diff === null) cur = 1;
  else if (diff === 1) cur += 1;
  else if (diff > 1) cur = 1;
  // diff <= 0: already counted today (or the timezone moved backwards): streak unchanged
  const longest = Math.max(st.longest_streak, cur);
  const last = diff !== null && diff < 0 ? st.last : today;
  await c.query(
    `UPDATE user_stats SET current_streak = $2, longest_streak = $3, last_activity_date = $4,
            total_saved_cents = total_saved_cents + $5, items_rescued = items_rescued + $6,
            meals_cooked = meals_cooked + 1, updated_at = now()
      WHERE user_id = $1`,
    [userId, cur, longest, last, savedCents, rescued],
  );
  return { currentStreak: cur, longestStreak: longest };
}

const money = (cents, currency) => {
  try { return new Intl.NumberFormat('en', { style: 'currency', currency }).format(cents / 100); } catch { return `${(cents / 100).toFixed(2)} ${currency}`; }
};

async function get(user, today) {
  const r = await db.query(
    `SELECT current_streak, longest_streak, to_char(last_activity_date, 'YYYY-MM-DD') AS last,
            total_saved_cents, items_rescued, meals_cooked FROM user_stats WHERE user_id = $1`, [user.id]);
  const st = r.rows[0] || { current_streak: 0, longest_streak: 0, last: null, total_saved_cents: 0, items_rescued: 0, meals_cooked: 0 };
  const diff = st.last ? daysBetween(st.last, today) : null;
  const alive = diff !== null && diff <= 1;
  const month = await db.query(
    'SELECT COALESCE(SUM(amount_cents), 0)::int AS c FROM savings_events WHERE user_id = $1 AND created_at >= $2',
    [user.id, monthBounds().startTs]);
  const active = await pantry.list(user.id);
  const expiringSoon = active
    .filter((i) => !i.is_staple && i.expires_on && daysBetween(today, i.expires_on) >= 0 && daysBetween(today, i.expires_on) <= 3)
    .slice(0, 8).map((i) => pantry.present(i, today));
  return {
    currentStreak: alive ? st.current_streak : 0,
    longestStreak: st.longest_streak,
    cookedToday: diff === 0,
    streakAtRisk: alive && diff === 1, // cook today to keep it going
    totalSavedCents: st.total_saved_cents,
    totalSaved: money(st.total_saved_cents, user.currency),
    savedThisMonthCents: month.rows[0].c,
    savedThisMonth: money(month.rows[0].c, user.currency),
    itemsRescued: st.items_rescued,
    mealsCooked: st.meals_cooked,
    expiringSoon,
    note: 'Savings are estimates based on typical prices, not receipts.',
  };
}

module.exports = { recordCook, get };
