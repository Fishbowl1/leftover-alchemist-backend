'use strict';
// Photo pipeline: sanitise -> dedupe -> reserve quota -> store -> detect -> (refund on failure).
const db = require('../db');
const config = require('../config');
const { AppError, E, log } = require('../errors');
const { localDate } = require('../lib/dates');
const { s } = require('../lib/validate');
const { CATEGORIES, STORAGE } = require('../lib/shelfLife');
const images = require('./images');
const quota = require('./quota');
const pantry = require('./pantry');
const vision = require('../ai/vision');

const PHOTO_COLS = `id, status, failure_code, detected_items, assessment, model, mime_type, bytes, width, height,
  (image_data IS NOT NULL) AS has_image, created_at, analyzed_at`;

function present(row) {
  return {
    id: row.id, status: row.status, failureCode: row.failure_code, items: row.detected_items || [],
    model: row.model, hasImage: row.has_image, width: row.width, height: row.height,
    createdAt: row.created_at, analyzedAt: row.analyzed_at,
  };
}

async function getRow(userId, id) {
  const r = await db.query(`SELECT ${PHOTO_COLS} FROM photos WHERE id = $1 AND user_id = $2`, [id, userId]);
  if (!r.rows[0]) throw E.notFound('Photo');
  return r.rows[0];
}

async function ingest(user, rawBuffer, { autoAdd = false } = {}) {
  const img = await images.prepareImage(rawBuffer);

  // Same photo again within 24h? Return the earlier result: no quota used, no AI cost.
  const dup = await db.query(
    `SELECT id FROM photos WHERE user_id = $1 AND sha256 = $2 AND status IN ('analyzed', 'confirmed') AND analyzed_at > $3
      ORDER BY id DESC LIMIT 1`,
    [user.id, img.sha256, new Date(Date.now() - 24 * 3600_000)],
  );
  if (dup.rows[0]) {
    return { photo: present(await getRow(user.id, dup.rows[0].id)), deduplicated: true, quota: await quota.status(user) };
  }

  const reservation = await quota.reservePhoto(user);
  let photoId;
  try {
    const ins = await db.query(
      `INSERT INTO photos (user_id, image_data, mime_type, bytes, width, height, sha256, status, quota_period_start)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'analyzing', $8) RETURNING id`,
      [user.id, img.buffer, img.mime, img.buffer.length, img.width, img.height, img.sha256, reservation.periodStart || null],
    );
    photoId = ins.rows[0].id;
  } catch (err) {
    await quota.refundPhoto(user, reservation);
    throw err;
  }
  return analyze(user, photoId, img.buffer, reservation, { autoAdd });
}

async function analyze(user, photoId, jpeg, reservation, { autoAdd }) {
  try {
    const today = localDate(user.timezone);
    const { data, model } = await vision.detect({ user, jpeg, today });
    const items = vision.interpret(data, today);
    await db.query(
      `UPDATE photos SET status = 'analyzed', detected_items = $2, assessment = $3, model = $4, analyzed_at = now(), failure_code = NULL
        WHERE id = $1`,
      [photoId, JSON.stringify(items), JSON.stringify(data.assessment), model],
    );
    let added = null;
    if (autoAdd) added = await confirm(user, photoId);
    return {
      photo: present(await getRow(user.id, photoId)),
      pantryItems: added ? added.items : undefined,
      warning: reservation.warning || undefined,
      quota: await quota.status(user),
    };
  } catch (err) {
    await quota.refundPhoto(user, reservation).catch((e) => log.error('quota refund failed', { err: e }));
    const code = err instanceof AppError ? err.code : 'analysis_failed';
    if (err instanceof AppError && err.status === 422) {
      // Rejected by moderation / unusable: delete the image bytes immediately.
      await db.query(`UPDATE photos SET status = 'rejected', failure_code = $2, image_data = NULL WHERE id = $1`, [photoId, code]);
    } else {
      await db.query(`UPDATE photos SET status = 'failed', failure_code = $2 WHERE id = $1`, [photoId, code]);
      if (err instanceof AppError) err.details = { ...(err.details || {}), photoId, canRetry: true };
    }
    throw err;
  }
}

// Retry a failed scan. The stored image is reused; a fresh quota credit is reserved
// (the failed attempt was refunded).
async function retry(user, photoId) {
  const claim = await db.query(
    `UPDATE photos SET status = 'analyzing' WHERE id = $1 AND user_id = $2 AND status IN ('failed', 'uploaded') AND image_data IS NOT NULL
      RETURNING image_data`,
    [photoId, user.id],
  );
  if (!claim.rows[0]) {
    const row = await getRow(user.id, photoId);
    throw E.conflict('cannot_retry', `This photo is "${row.status}" and cannot be re-analyzed.`);
  }
  let reservation;
  try { reservation = await quota.reservePhoto(user); } catch (err) {
    await db.query(`UPDATE photos SET status = 'failed' WHERE id = $1`, [photoId]);
    throw err;
  }
  await db.query('UPDATE photos SET quota_period_start = $2 WHERE id = $1', [photoId, reservation.periodStart || null]);
  return analyze(user, photoId, claim.rows[0].image_data, reservation, { autoAdd: false });
}

const CONFIRM_ITEMS = s.array(s.object({
  name: s.string({ min: 1, max: 80 }),
  quantity: s.number({ min: 0.001, max: 100000 }),
  unit: s.string({ min: 1, max: 20 }),
  category: s.enum(CATEGORIES).optional(),
  storage: s.enum(STORAGE).optional(),
  expiresOn: s.string({ max: 10 }).optional(),
  isStaple: s.boolean().optional(),
}), { min: 1, max: 100 });

// Commit the (optionally user-corrected) detected items into the pantry.
async function confirm(user, photoId, overrideItems) {
  const today = localDate(user.timezone);
  return db.withTransaction(async (c) => {
    const r = await c.query(`SELECT status, detected_items FROM photos WHERE id = $1 AND user_id = $2 FOR UPDATE`, [photoId, user.id]);
    const row = r.rows[0];
    if (!row) throw E.notFound('Photo');
    if (row.status === 'confirmed') throw E.conflict('already_confirmed', 'These items were already added to your pantry.');
    if (row.status !== 'analyzed') throw E.conflict('not_ready', `This photo is "${row.status}", so it cannot be confirmed yet.`);

    const source = overrideItems
      ? overrideItems
      : (row.detected_items || []).map((i) => ({
        name: i.name, quantity: i.quantity, unit: i.unit, category: i.category, storage: i.storage,
        expiresOn: i.expires_on, expirySource: i.expiry_source, freshness: i.freshness, valueCents: i.est_value_cents,
      }));
    const items = [];
    for (const it of source) {
      const { item } = await pantry.addOrMerge(c, user.id, { ...it, sourcePhotoId: photoId }, today);
      items.push(pantry.present(item, today));
    }
    await c.query(`UPDATE photos SET status = 'confirmed' WHERE id = $1`, [photoId]);
    return { items };
  });
}

async function list(userId, limit = 20) {
  const r = await db.query(`SELECT ${PHOTO_COLS} FROM photos WHERE user_id = $1 ORDER BY id DESC LIMIT $2`, [userId, limit]);
  return r.rows.map(present);
}

async function getImage(userId, id) {
  const r = await db.query('SELECT image_data, mime_type FROM photos WHERE id = $1 AND user_id = $2', [id, userId]);
  if (!r.rows[0] || !r.rows[0].image_data) throw E.notFound('Photo image');
  return r.rows[0];
}

async function remove(userId, id) {
  const r = await db.query('DELETE FROM photos WHERE id = $1 AND user_id = $2', [id, userId]);
  if (!r.rowCount) throw E.notFound('Photo');
}

// Maintenance (run daily): drop original image bytes after the retention window and
// recover scans stuck in "analyzing" (e.g. the server restarted mid-call), refunding their credit.
async function cleanup() {
  const cutoff = new Date(Date.now() - config.photoRetentionDays * 86400_000);
  const purged = await db.query(`UPDATE photos SET image_data = NULL WHERE image_data IS NOT NULL AND created_at < $1`, [cutoff]);
  const stuck = await db.query(
    `UPDATE photos SET status = 'failed', failure_code = 'interrupted'
      WHERE status = 'analyzing' AND created_at < $1 RETURNING user_id, quota_period_start`,
    [new Date(Date.now() - 10 * 60_000)],
  );
  for (const p of stuck.rows) {
    if (p.quota_period_start) {
      await db.query(
        `UPDATE usage_periods SET photos_used = GREATEST(photos_used - 1, 0) WHERE user_id = $1 AND period_start = $2`,
        [p.user_id, p.quota_period_start],
      );
    }
  }
  const sessions = await db.query('DELETE FROM sessions WHERE expires_at < now()');
  return { imagesPurged: purged.rowCount, scansRecovered: stuck.rowCount, sessionsDeleted: sessions.rowCount };
}

module.exports = { ingest, retry, confirm, list, getRow, getImage, remove, present, cleanup, CONFIRM_ITEMS };
