'use strict';
const crypto = require('crypto');
const { promisify } = require('util');
const db = require('../db');
const config = require('../config');
const { E } = require('../errors');

const scrypt = promisify(crypto.scrypt);
const N = 32768; const R = 8; const P = 1; const KEYLEN = 64;
const MAXMEM = 64 * 1024 * 1024;

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = await scrypt(pw, salt, KEYLEN, { N, r: R, p: P, maxmem: MAXMEM });
  return `scrypt$${N}$${R}$${P}$${salt.toString('base64')}$${hash.toString('base64')}`;
}

async function verifyPassword(pw, stored) {
  const [alg, n, r, p, saltB64, hashB64] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(hashB64, 'base64');
  const actual = await scrypt(pw, Buffer.from(saltB64, 'base64'), expected.length, { N: +n, r: +r, p: +p, maxmem: MAXMEM });
  return crypto.timingSafeEqual(actual, expected);
}

let dummyHash = null; // used so "unknown email" takes as long as "wrong password"
const getDummy = async () => dummyHash || (dummyHash = await hashPassword('not-a-real-password'));

const hashToken = (t) => crypto.createHash('sha256').update(t).digest('hex');

async function createSession(userId, client = db) {
  const token = crypto.randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + config.sessionTtlDays * 86400_000);
  await client.query('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES ($1, $2, $3)', [hashToken(token), userId, expires]);
  return { token, expiresAt: expires };
}

const USER_COLS = 'id, email, plan, timezone, currency';

async function signup({ email, password, timezone, currency }) {
  const hash = await hashPassword(password);
  try {
    return await db.withTransaction(async (c) => {
      const r = await c.query(
        `INSERT INTO users (email, password_hash, timezone, currency) VALUES ($1, $2, $3, $4) RETURNING ${USER_COLS}`,
        [email, hash, timezone || 'UTC', currency || 'EUR'],
      );
      const user = r.rows[0];
      await c.query('INSERT INTO user_preferences (user_id) VALUES ($1)', [user.id]);
      await c.query('INSERT INTO user_stats (user_id) VALUES ($1)', [user.id]);
      const session = await createSession(user.id, c);
      return { user, ...session };
    });
  } catch (err) {
    if (err.code === '23505') throw E.conflict('email_taken', 'An account with that email already exists. Try signing in.');
    throw err;
  }
}

async function login({ email, password }) {
  const r = await db.query('SELECT id, email, plan, timezone, currency, password_hash FROM users WHERE email = $1', [email]);
  const row = r.rows[0];
  const ok = await verifyPassword(password, row ? row.password_hash : await getDummy());
  if (!row || !ok) throw E.unauthorized('Incorrect email or password.');
  const { password_hash: _ph, ...user } = row;
  return { user, ...(await createSession(user.id)) };
}

async function authenticate(token) {
  if (!token) return null;
  const r = await db.query(
    `SELECT u.id, u.email, u.plan, u.timezone, u.currency
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = $1 AND s.expires_at > now()`,
    [hashToken(token)],
  );
  if (!r.rows[0]) return null;
  // sliding "last used" marker, written at most hourly
  await db.query(
    `UPDATE sessions SET last_used_at = now() WHERE token_hash = $1 AND last_used_at < now() - interval '1 hour'`,
    [hashToken(token)],
  );
  return r.rows[0];
}

const logout = (token) => db.query('DELETE FROM sessions WHERE token_hash = $1', [hashToken(token)]);
const logoutAll = (userId) => db.query('DELETE FROM sessions WHERE user_id = $1', [userId]);

// Permanently deletes the account and (via ON DELETE CASCADE) every photo, pantry item,
// recipe, preference, session and stat belonging to it.
async function deleteAccount(userId, password) {
  const r = await db.query('SELECT password_hash FROM users WHERE id = $1', [userId]);
  if (!r.rows[0] || !(await verifyPassword(password, r.rows[0].password_hash))) throw E.forbidden('wrong_password', 'That password is not correct.');
  await db.query('DELETE FROM users WHERE id = $1', [userId]);
}

module.exports = { hashPassword, verifyPassword, signup, login, authenticate, logout, logoutAll, deleteAccount, createSession };
