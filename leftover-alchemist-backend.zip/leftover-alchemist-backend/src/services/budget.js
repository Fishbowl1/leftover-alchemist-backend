'use strict';
// AI spend limits. Every AI call is recorded in ai_usage with its real token cost.
// Calls are refused when a user exceeds their monthly AI allowance, or when the whole
// service exceeds its daily kill-switch budget. Limits can overshoot by one in-flight
// call per concurrent request; that is acceptable for a cost guard-rail.
const db = require('../db');
const config = require('../config');
const { E } = require('../errors');
const { monthBounds, startOfUtcDay } = require('../lib/dates');

const micros = (n) => Number(n) || 0;
const dollars = (m) => Math.round(m / 1e4) / 100;

async function userMonthSpend(userId) {
  const r = await db.query(
    'SELECT COALESCE(SUM(cost_micros), 0)::float8 AS s FROM ai_usage WHERE user_id = $1 AND created_at >= $2',
    [userId, monthBounds().startTs],
  );
  return micros(r.rows[0].s);
}

async function globalDaySpend() {
  const r = await db.query('SELECT COALESCE(SUM(cost_micros), 0)::float8 AS s FROM ai_usage WHERE created_at >= $1', [startOfUtcDay()]);
  return micros(r.rows[0].s);
}

const limitFor = (user) => (user && user.plan === 'paid' ? config.budgets.paidMonthlyMicros : config.budgets.freeMonthlyMicros);

async function assertWithinBudget(user) {
  if (user) {
    if ((await userMonthSpend(user.id)) >= limitFor(user)) {
      throw E.tooMany('ai_budget_exceeded',
        user.plan === 'paid'
          ? 'You have reached this month\'s AI allowance. It resets on the 1st.'
          : 'You have reached this month\'s free AI allowance. Upgrade for more, or it resets on the 1st.');
    }
  }
  if ((await globalDaySpend()) >= config.budgets.globalDailyMicros) {
    throw E.tooMany('service_at_capacity', 'We are at capacity for today. Please try again tomorrow.');
  }
}

function costMicros(model, inputTokens, outputTokens) {
  const p = config.priceFor(model); // USD per million tokens, so tokens * price = micro-dollars
  return Math.round(inputTokens * p.in + outputTokens * p.out);
}

async function record({ userId, kind, model, inputTokens, outputTokens, status, attempts, latencyMs, error }) {
  const cost = costMicros(model, inputTokens, outputTokens);
  await db.query(
    `INSERT INTO ai_usage (user_id, kind, model, input_tokens, output_tokens, cost_micros, status, attempts, latency_ms, error)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
    [userId || null, kind, model, inputTokens, outputTokens, cost, status, attempts, latencyMs, error ? String(error).slice(0, 300) : null],
  );
  return cost;
}

async function summary(user) {
  const spent = await userMonthSpend(user.id);
  const limit = limitFor(user);
  return { spentUsd: dollars(spent), limitUsd: dollars(limit), remainingUsd: dollars(Math.max(0, limit - spent)) };
}

module.exports = { assertWithinBudget, record, costMicros, summary, userMonthSpend, globalDaySpend };
