'use strict';
const db = require('../db');
const { s } = require('../lib/validate');
const { DIET_KEYS, resolveAllergy } = require('../lib/allergens');

const SCHEMA = s.object({
  allergies: s.array(s.string({ min: 1, max: 40 }), { max: 20 }).optional(),
  diets: s.array(s.enum(DIET_KEYS), { max: 8 }).optional(),
  dislikedIngredients: s.array(s.string({ min: 1, max: 40 }), { max: 40 }).optional(),
  householdSize: s.integer({ min: 1, max: 20 }).optional(),
  defaultMaxMinutes: s.integer({ min: 5, max: 480 }).optional(),
  skillLevel: s.enum(['beginner', 'intermediate', 'advanced']).optional(),
});

const DEFAULTS = { allergies: [], diets: [], disliked_ingredients: [], household_size: 2, default_max_minutes: 30, skill_level: 'intermediate' };
const uniqLower = (arr) => [...new Set(arr.map((x) => x.toLowerCase()))];

async function get(userId, client = db) {
  const r = await client.query(
    `SELECT allergies, diets, disliked_ingredients, household_size, default_max_minutes, skill_level
       FROM user_preferences WHERE user_id = $1`, [userId]);
  return r.rows[0] || { ...DEFAULTS };
}

async function update(userId, patch) {
  const cur = await get(userId);
  const next = {
    allergies: patch.allergies ? uniqLower(patch.allergies) : cur.allergies,
    diets: patch.diets ? [...new Set(patch.diets)] : cur.diets,
    disliked_ingredients: patch.dislikedIngredients ? uniqLower(patch.dislikedIngredients) : cur.disliked_ingredients,
    household_size: patch.householdSize ?? cur.household_size,
    default_max_minutes: patch.defaultMaxMinutes ?? cur.default_max_minutes,
    skill_level: patch.skillLevel ?? cur.skill_level,
  };
  await db.query(
    `INSERT INTO user_preferences (user_id, allergies, diets, disliked_ingredients, household_size, default_max_minutes, skill_level, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, now())
     ON CONFLICT (user_id) DO UPDATE SET allergies = $2, diets = $3, disliked_ingredients = $4,
       household_size = $5, default_max_minutes = $6, skill_level = $7, updated_at = now()`,
    [userId, next.allergies, next.diets, next.disliked_ingredients, next.household_size, next.default_max_minutes, next.skill_level],
  );
  return next;
}

function present(p) {
  return {
    allergies: p.allergies,
    // tells the user which allergies are fully understood vs matched only by the exact word they typed
    allergyCoverage: p.allergies.map((a) => ({ input: a, recognised: !resolveAllergy(a)[0].key.startsWith('custom:') })),
    diets: p.diets,
    dislikedIngredients: p.disliked_ingredients,
    householdSize: p.household_size,
    defaultMaxMinutes: p.default_max_minutes,
    skillLevel: p.skill_level,
  };
}

module.exports = { SCHEMA, get, update, present };
