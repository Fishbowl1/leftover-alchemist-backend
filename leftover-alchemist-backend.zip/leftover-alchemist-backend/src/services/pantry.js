'use strict';
// Persistent pantry: items with quantity, unit, freshness and an expiry date.
const db = require('../db');
const { E } = require('../errors');
const { normalizeName } = require('../lib/names');
const { normalizeUnit, convert } = require('../lib/units');
const { daysBetween, isValidYmd } = require('../lib/dates');
const { estimateExpiry, estimateValueCents, guessCategory, worseFreshness, CATEGORIES } = require('../lib/shelfLife');
const { flagItem } = require('../lib/allergens');

const COLS = `id, name, normalized_name, category, storage, quantity::float8 AS quantity, unit, is_staple, freshness,
  to_char(expires_on, 'YYYY-MM-DD') AS expires_on, expiry_source, est_value_cents, source_photo_id, status, added_at, updated_at`;

const round3 = (n) => Math.round(n * 1000) / 1000;

async function list(userId, { status = 'active', client = db, lock = false } = {}) {
  const r = await client.query(
    `SELECT ${COLS} FROM pantry_items WHERE user_id = $1 AND status = $2 ORDER BY expires_on NULLS LAST, name${lock ? ' FOR UPDATE' : ''}`,
    [userId, status],
  );
  return r.rows;
}

async function getOne(userId, id, client = db) {
  const r = await client.query(`SELECT ${COLS} FROM pantry_items WHERE id = $1 AND user_id = $2`, [id, userId]);
  if (!r.rows[0]) throw E.notFound('Pantry item');
  return r.rows[0];
}

const daysLeft = (item, today) => (item.expires_on ? daysBetween(today, item.expires_on) : null);

// Usable for cooking = not spoiled and not past its date. Everything else is surfaced to
// the user as "consider discarding" and is never passed to the recipe model.
function splitUsable(items, today) {
  const usable = []; const excluded = [];
  for (const i of items) {
    const d = daysLeft(i, today);
    if (!i.is_staple && (i.freshness === 'spoiled' || (d !== null && d < 0))) excluded.push(i); else usable.push(i);
  }
  return { usable, excluded };
}

function present(item, today, prefs) {
  const d = daysLeft(item, today);
  return {
    id: item.id, name: item.name, category: item.category, storage: item.storage,
    quantity: item.quantity, unit: item.unit, isStaple: item.is_staple, freshness: item.freshness,
    expiresOn: item.expires_on, expirySource: item.expiry_source, daysLeft: d,
    urgency: item.is_staple || d === null ? 'none' : d < 0 ? 'expired' : d === 0 ? 'today' : d <= 3 ? 'soon' : 'ok',
    estValueCents: item.est_value_cents, sourcePhotoId: item.source_photo_id,
    ...(prefs ? { flags: flagItem(item.name, prefs) } : {}),
  };
}

// Normalise a loosely specified item (from the user, a photo, or a shopping trip).
function prepareItem(input, today) {
  const name = String(input.name || '').trim();
  const normalized = normalizeName(name);
  if (!normalized) throw E.badRequest('invalid_name', 'Please give the item a name.');
  const category = CATEGORIES.includes(input.category) ? input.category : guessCategory(name);
  const unit = normalizeUnit(input.unit);
  const quantity = input.isStaple ? 1 : round3(Number(input.quantity));
  if (!(quantity > 0)) throw E.badRequest('invalid_quantity', 'Quantity must be more than zero.');
  const freshness = input.freshness || 'unknown';
  let expiresOn = null; let expirySource = 'estimated';
  if (!input.isStaple) {
    if (input.expiresOn) {
      if (!isValidYmd(input.expiresOn)) throw E.badRequest('invalid_date', 'Expiry date must look like 2026-12-31.');
      expiresOn = input.expiresOn; expirySource = input.expirySource || 'user';
    } else {
      const est = estimateExpiry({ category, storage: input.storage || 'unknown', freshness: freshness === 'unknown' ? 'fresh' : freshness, today });
      expiresOn = est.expiresOn; expirySource = est.source;
    }
  }
  return {
    name: name.slice(0, 80), normalized, category, storage: input.storage || 'unknown', quantity, unit, freshness,
    expiresOn, expirySource, isStaple: !!input.isStaple, sourcePhotoId: input.sourcePhotoId || null,
    valueCents: input.isStaple ? 0 : (input.valueCents ?? estimateValueCents(category, quantity, unit)),
  };
}

// Adds an item, merging into an existing active item of the same name when units are compatible.
async function addOrMerge(client, userId, input, today) {
  const it = prepareItem(input, today);
  const existing = (await client.query(
    `SELECT ${COLS} FROM pantry_items WHERE user_id = $1 AND normalized_name = $2 AND status = 'active' FOR UPDATE`,
    [userId, it.normalized],
  )).rows;
  const target = existing.find((e) => e.unit === it.unit) || existing.find((e) => convert(1, it.unit, e.unit) !== null);
  if (target) {
    const add = convert(it.quantity, it.unit, target.unit);
    const quantity = it.isStaple ? target.quantity : round3(target.quantity + add);
    // keep the EARLIEST expiry when merging fresh stock into older stock (conservative)
    const expires = [target.expires_on, it.expiresOn].filter(Boolean).sort()[0] || null;
    const r = await client.query(
      `UPDATE pantry_items SET quantity = $2, expires_on = $3, freshness = $4, est_value_cents = $5, is_staple = $6, updated_at = now()
        WHERE id = $1 RETURNING ${COLS}`,
      [target.id, quantity, expires, worseFreshness(target.freshness, it.freshness), target.est_value_cents + it.valueCents, target.is_staple || it.isStaple],
    );
    return { item: r.rows[0], merged: true };
  }
  const r = await client.query(
    `INSERT INTO pantry_items (user_id, name, normalized_name, category, storage, quantity, unit, is_staple, freshness,
                               expires_on, expiry_source, est_value_cents, source_photo_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13) RETURNING ${COLS}`,
    [userId, it.name, it.normalized, it.category, it.storage, it.quantity, it.unit, it.isStaple, it.freshness,
      it.expiresOn, it.expirySource, it.valueCents, it.sourcePhotoId],
  );
  return { item: r.rows[0], merged: false };
}

async function update(userId, id, patch, today) {
  const cur = await getOne(userId, id);
  const sets = []; const vals = [id, userId];
  const set = (col, v) => { vals.push(v); sets.push(`${col} = $${vals.length}`); };
  if (patch.name !== undefined) {
    const n = normalizeName(patch.name);
    if (!n) throw E.badRequest('invalid_name', 'Please give the item a name.');
    set('name', patch.name.slice(0, 80)); set('normalized_name', n);
  }
  if (patch.unit !== undefined) set('unit', normalizeUnit(patch.unit));
  if (patch.category !== undefined) set('category', patch.category);
  if (patch.storage !== undefined) set('storage', patch.storage);
  if (patch.isStaple !== undefined) set('is_staple', patch.isStaple);
  if (patch.freshness !== undefined) set('freshness', patch.freshness);
  if (patch.expiresOn !== undefined) {
    if (patch.expiresOn !== null && !isValidYmd(patch.expiresOn)) throw E.badRequest('invalid_date', 'Expiry date must look like 2026-12-31.');
    set('expires_on', patch.expiresOn); set('expiry_source', 'user');
  }
  if (patch.quantity !== undefined) {
    set('quantity', round3(patch.quantity));
    if (patch.quantity === 0) set('status', 'used');
    else if (cur.quantity > 0) set('est_value_cents', Math.round(cur.est_value_cents * (patch.quantity / cur.quantity)));
  }
  if (!sets.length) return cur;
  const r = await db.query(`UPDATE pantry_items SET ${sets.join(', ')}, updated_at = now() WHERE id = $1 AND user_id = $2 RETURNING ${COLS}`, vals);
  return r.rows[0];
}

async function setStatus(userId, id, status) {
  const r = await db.query(
    `UPDATE pantry_items SET status = $3, quantity = CASE WHEN $3 = 'active' THEN quantity ELSE 0 END, updated_at = now()
      WHERE id = $1 AND user_id = $2 AND status = 'active' RETURNING ${COLS}`,
    [id, userId, status],
  );
  if (!r.rows[0]) throw E.notFound('Active pantry item');
  return r.rows[0];
}

async function remove(userId, id) {
  const r = await db.query('DELETE FROM pantry_items WHERE id = $1 AND user_id = $2', [id, userId]);
  if (!r.rowCount) throw E.notFound('Pantry item');
}

module.exports = { COLS, list, getOne, splitUsable, present, addOrMerge, update, setStatus, remove, daysLeft, round3 };
