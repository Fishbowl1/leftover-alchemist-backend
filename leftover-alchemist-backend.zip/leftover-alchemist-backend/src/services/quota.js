'use strict';
// Free-tier photo-scan quota. The count is reserved ATOMICALLY before any paid AI work
// (so parallel requests cannot overshoot) and refunded if the scan fails or is rejected,
// so users never lose a free scan to an error on our side.
const db = require('../db');
const config = require('../config');
const { E } = require('../errors');
const { monthBounds } = require('../lib/dates');

function nextReset() {
  const { end } = monthBounds();
  const d = new Date(`${end}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + 1);
  return d.toISOString().slice(0, 10);
}

async function reservePhoto(user) {
  if (user.plan === 'paid') return { limited: false };
  const { start, end } = monthBounds();
  const limit = config.quota.freePhotosPerMonth;
  await db.query(
    `INSERT INTO usage_periods (user_id, period_start, period_end, photos_used)
     VALUES ($1, $2, $3, 0) ON CONFLICT (user_id, period_start) DO NOTHING`,
    [user.id, start, end],
  );
  const r = await db.query(
    `UPDATE usage_periods SET photos_used = photos_used + 1
      WHERE user_id = $1 AND period_start = $2 AND photos_used < $3
      RETURNING photos_used`,
    [user.id, start, limit],
  );
  if (!r.rows[0]) {
    await db.query(`INSERT INTO paywall_events (user_id, trigger) VALUES ($1, 'photo_cap')`, [user.id]);
    throw E.paymentRequired('photo_limit_reached',
      `You've used all ${limit} free photo scans this month. Upgrade for unlimited scans, or come back on ${nextReset()}.`,
      { limit, resetsOn: nextReset() });
  }
  const used = r.rows[0].photos_used;
  return {
    limited: true, periodStart: start, used, limit, remaining: limit - used,
    warning: used === limit - 1 ? `Heads up: ${limit - used} free scan left this month.` : null,
  };
}

async function refundPhoto(user, reservation) {
  if (!reservation || !reservation.limited) return;
  await db.query(
    `UPDATE usage_periods SET photos_used = GREATEST(photos_used - 1, 0) WHERE user_id = $1 AND period_start = $2`,
    [user.id, reservation.periodStart],
  );
}

async function status(user) {
  if (user.plan === 'paid') return { plan: 'paid', unlimited: true };
  const { start } = monthBounds();
  const limit = config.quota.freePhotosPerMonth;
  const r = await db.query('SELECT photos_used FROM usage_periods WHERE user_id = $1 AND period_start = $2', [user.id, start]);
  const used = r.rows[0] ? r.rows[0].photos_used : 0;
  return { plan: 'free', unlimited: false, used, limit, remaining: Math.max(0, limit - used), resetsOn: nextReset() };
}

module.exports = { reservePhoto, refundPhoto, status };
