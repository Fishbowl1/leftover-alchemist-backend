'use strict';
const config = require('./config');
const db = require('./db');
const { migrate } = require('./migrate');
const { createApp } = require('./app');
const photos = require('./services/photos');
const { log } = require('./errors');

async function main() {
  if (config.autoMigrate) await migrate();
  const app = createApp();
  const server = app.listen(config.port, () => log.info('Leftover Alchemist API listening', { port: config.port, env: config.env, aiConfigured: Boolean(config.ai.apiKey) }));
  server.keepAliveTimeout = 65_000; // longer than typical load-balancer idle timeouts

  // housekeeping: purge old photo bytes, recover interrupted scans, drop expired sessions
  const runCleanup = () => photos.cleanup().then((r) => log.info('cleanup finished', r)).catch((e) => log.error('cleanup failed', { err: e }));
  setTimeout(runCleanup, 30_000).unref();
  setInterval(runCleanup, 6 * 3600_000).unref();

  const stop = (sig) => {
    log.info('shutting down', { sig });
    server.close(() => db.close().then(() => process.exit(0)));
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => stop('SIGTERM'));
  process.on('SIGINT', () => stop('SIGINT'));
}

main().catch((err) => { log.error('failed to start', { err }); process.exit(1); });
