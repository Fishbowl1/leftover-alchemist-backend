'use strict';
const express = require('express');
const config = require('../config');
const { E } = require('../errors');
const { s } = require('../lib/validate');
const { localDate } = require('../lib/dates');
const recipes = require('../services/recipeService');
const shopping = require('../services/shopping');
const stats = require('../services/stats');
const { asyncHandler: ah, requireAuth, parse, rateLimit } = require('../middleware/common');

const SERVINGS = s.object({ servings: s.integer({ min: 1, max: 20 }).optional() });
const STATUS = s.object({ status: s.enum(['saved', 'dismissed', 'suggested']) });
const ITEM = s.object({
  name: s.string({ min: 1, max: 80 }),
  quantity: s.number({ min: 0.001, max: 100000 }).default(1),
  unit: s.string({ min: 1, max: 20 }).default('count'),
});
const ITEM_PATCH = s.object({ checked: s.boolean().optional(), quantity: s.number({ min: 0.001, max: 100000 }).optional() });

const rid = (v, what) => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw E.notFound(what); return n; };
const servingsFrom = (q) => {
  if (q.servings === undefined) return undefined;
  return parse(SERVINGS, { servings: Number(q.servings) }).servings;
};

const recipeRouter = express.Router();
recipeRouter.use(requireAuth);
const genLimiter = rateLimit({ windowMs: 3600_000, max: config.rate.recipesPerHour, key: (req) => req.user.id, message: 'You are generating recipes very quickly. Please wait a bit.' });

recipeRouter.post('/generate', genLimiter, ah(async (req, res) => {
  const input = parse(recipes.GENERATE, req.body || {});
  const out = await recipes.generate(req.user, input);
  res.status(out.cached ? 200 : 201).json(out);
}));
recipeRouter.get('/', ah(async (req, res) => {
  const status = ['suggested', 'saved', 'cooked', 'dismissed'].includes(req.query.status) ? req.query.status : undefined;
  res.json({ recipes: await recipes.list(req.user, status) });
}));
recipeRouter.get('/:id', ah(async (req, res) => { res.json({ recipe: await recipes.get(req.user, rid(req.params.id, 'Recipe'), servingsFrom(req.query)) }); }));
recipeRouter.patch('/:id', ah(async (req, res) => {
  const b = parse(STATUS, req.body);
  res.json({ recipe: await recipes.setStatus(req.user, rid(req.params.id, 'Recipe'), b.status) });
}));
recipeRouter.post('/:id/cook', ah(async (req, res) => {
  const b = parse(SERVINGS, req.body || {});
  res.json(await recipes.cook(req.user, rid(req.params.id, 'Recipe'), { servings: b.servings }));
}));
recipeRouter.post('/:id/shopping-list', ah(async (req, res) => {
  const b = parse(SERVINGS, req.body || {});
  res.status(201).json(await shopping.addFromRecipe(req.user, rid(req.params.id, 'Recipe'), b.servings));
}));

const shoppingRouter = express.Router();
shoppingRouter.use(requireAuth);
shoppingRouter.get('/', ah(async (req, res) => { res.json({ items: (await shopping.list(req.user.id)).map(shopping.present) }); }));
shoppingRouter.post('/items', ah(async (req, res) => { res.status(201).json({ item: await shopping.addItem(req.user.id, parse(ITEM, req.body)) }); }));
shoppingRouter.patch('/items/:id', ah(async (req, res) => { res.json({ item: await shopping.updateItem(req.user.id, rid(req.params.id, 'Shopping item'), parse(ITEM_PATCH, req.body)) }); }));
shoppingRouter.delete('/items/:id', ah(async (req, res) => { await shopping.removeItem(req.user.id, rid(req.params.id, 'Shopping item')); res.sendStatus(204); }));
shoppingRouter.delete('/checked', ah(async (req, res) => { res.json({ removed: await shopping.clearChecked(req.user.id) }); }));
shoppingRouter.post('/purchase', ah(async (req, res) => { res.json(await shopping.purchase(req.user)); }));

const statsRouter = express.Router();
statsRouter.use(requireAuth);
statsRouter.get('/', ah(async (req, res) => { res.json(await stats.get(req.user, localDate(req.user.timezone))); }));

module.exports = { recipeRouter, shoppingRouter, statsRouter };
