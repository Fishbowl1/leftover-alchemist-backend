'use strict';
const express = require('express');
const db = require('../db');
const { E } = require('../errors');
const { s } = require('../lib/validate');
const { localDate } = require('../lib/dates');
const { CATEGORIES, STORAGE, FRESHNESS } = require('../lib/shelfLife');
const pantry = require('../services/pantry');
const prefs = require('../services/preferences');
const { asyncHandler: ah, requireAuth, parse } = require('../middleware/common');

const router = express.Router();
router.use(requireAuth);

const ADD = s.object({
  name: s.string({ min: 1, max: 80 }),
  quantity: s.number({ min: 0.001, max: 100000 }).default(1),
  unit: s.string({ min: 1, max: 20 }).default('count'),
  category: s.enum(CATEGORIES).optional(),
  storage: s.enum(STORAGE).optional(),
  expiresOn: s.string({ max: 10 }).optional(),
  isStaple: s.boolean().optional(),
});
const PATCH = s.object({
  name: s.string({ min: 1, max: 80 }).optional(),
  quantity: s.number({ min: 0, max: 100000 }).optional(),
  unit: s.string({ min: 1, max: 20 }).optional(),
  category: s.enum(CATEGORIES).optional(),
  storage: s.enum(STORAGE).optional(),
  freshness: s.enum(FRESHNESS).optional(),
  expiresOn: s.string({ max: 10 }).nullable().optional(),
  isStaple: s.boolean().optional(),
});

const id = (v) => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw E.notFound('Pantry item'); return n; };

router.get('/', ah(async (req, res) => {
  const today = localDate(req.user.timezone);
  const status = ['active', 'used', 'discarded'].includes(req.query.status) ? req.query.status : 'active';
  const p = await prefs.get(req.user.id);
  const rows = await pantry.list(req.user.id, { status });
  const items = rows.map((r) => pantry.present(r, today, p));
  res.json({
    items,
    summary: status === 'active' ? {
      total: items.length,
      expiringSoon: items.filter((i) => i.urgency === 'soon' || i.urgency === 'today').length,
      expired: items.filter((i) => i.urgency === 'expired').length,
      flagged: items.filter((i) => i.flags && i.flags.length).length,
    } : undefined,
  });
}));

router.post('/', ah(async (req, res) => {
  const b = parse(ADD, req.body);
  const today = localDate(req.user.timezone);
  const out = await db.withTransaction((c) => pantry.addOrMerge(c, req.user.id, b, today));
  res.status(out.merged ? 200 : 201).json({ item: pantry.present(out.item, today, await prefs.get(req.user.id)), merged: out.merged });
}));

router.patch('/:id', ah(async (req, res) => {
  const b = parse(PATCH, req.body);
  const today = localDate(req.user.timezone);
  res.json({ item: pantry.present(await pantry.update(req.user.id, id(req.params.id), b, today), today) });
}));
router.post('/:id/discard', ah(async (req, res) => { res.json({ item: pantry.present(await pantry.setStatus(req.user.id, id(req.params.id), 'discarded'), localDate(req.user.timezone)) }); }));
router.post('/:id/used-up', ah(async (req, res) => { res.json({ item: pantry.present(await pantry.setStatus(req.user.id, id(req.params.id), 'used'), localDate(req.user.timezone)) }); }));
router.delete('/:id', ah(async (req, res) => { await pantry.remove(req.user.id, id(req.params.id)); res.sendStatus(204); }));

module.exports = router;
