'use strict';
const express = require('express');
const db = require('../db');
const config = require('../config');
const { E } = require('../errors');
const { s } = require('../lib/validate');
const { isValidTimezone } = require('../lib/dates');
const auth = require('../services/auth');
const prefs = require('../services/preferences');
const quota = require('../services/quota');
const budget = require('../services/budget');
const { asyncHandler: ah, requireAuth, parse, rateLimit } = require('../middleware/common');

const authLimiter = rateLimit({ windowMs: 15 * 60_000, max: config.rate.authPer15Min, message: 'Too many sign-in attempts. Please wait a few minutes.' });
const COMMON = new Set(['password12', 'password123', 'password1234', '1234567890', '12345678910', 'qwertyuiop', 'letmein1234', 'iloveyou123']);

const SIGNUP = s.object({
  email: s.string({ min: 3, max: 254, pattern: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, patternMessage: 'must be a valid email address' }),
  password: s.string({ min: 10, max: 128, raw: true }),
  timezone: s.string({ max: 60 }).optional(),
  currency: s.string({ min: 3, max: 3, pattern: /^[A-Za-z]{3}$/ }).optional(),
});
const LOGIN = s.object({ email: s.string({ min: 3, max: 254 }), password: s.string({ min: 1, max: 128, raw: true }) });
const PROFILE = s.object({
  timezone: s.string({ max: 60 }).optional(),
  currency: s.string({ min: 3, max: 3, pattern: /^[A-Za-z]{3}$/ }).optional(),
});
const DELETE = s.object({ password: s.string({ min: 1, max: 128, raw: true }) });

const userOut = (u) => ({ id: u.id, email: u.email, plan: u.plan, timezone: u.timezone, currency: u.currency });

const authRouter = express.Router();
authRouter.post('/signup', authLimiter, ah(async (req, res) => {
  const b = parse(SIGNUP, req.body);
  if (b.timezone && !isValidTimezone(b.timezone)) throw E.badRequest('invalid_timezone', 'Timezone must be an IANA name like "Europe/Dublin".');
  if (COMMON.has(b.password.toLowerCase())) throw E.badRequest('weak_password', 'That password is too easy to guess. Please choose another.');
  const out = await auth.signup({ email: b.email.toLowerCase(), password: b.password, timezone: b.timezone, currency: b.currency && b.currency.toUpperCase() });
  res.status(201).json({ user: userOut(out.user), token: out.token, expiresAt: out.expiresAt });
}));
authRouter.post('/login', authLimiter, ah(async (req, res) => {
  const b = parse(LOGIN, req.body);
  const out = await auth.login({ email: b.email.toLowerCase(), password: b.password });
  res.json({ user: userOut(out.user), token: out.token, expiresAt: out.expiresAt });
}));
authRouter.post('/logout', requireAuth, ah(async (req, res) => { await auth.logout(req.token); res.sendStatus(204); }));
authRouter.post('/logout-all', requireAuth, ah(async (req, res) => { await auth.logoutAll(req.user.id); res.sendStatus(204); }));

const me = express.Router();
me.use(requireAuth);
me.get('/', ah(async (req, res) => {
  const [p, q, ai] = await Promise.all([prefs.get(req.user.id), quota.status(req.user), budget.summary(req.user)]);
  res.json({ user: userOut(req.user), preferences: prefs.present(p), photoQuota: q, aiAllowance: ai });
}));
me.patch('/', ah(async (req, res) => {
  const b = parse(PROFILE, req.body);
  if (b.timezone && !isValidTimezone(b.timezone)) throw E.badRequest('invalid_timezone', 'Timezone must be an IANA name like "Europe/Dublin".');
  const r = await db.query(
    `UPDATE users SET timezone = COALESCE($2, timezone), currency = COALESCE($3, currency) WHERE id = $1
     RETURNING id, email, plan, timezone, currency`,
    [req.user.id, b.timezone || null, b.currency ? b.currency.toUpperCase() : null]);
  res.json({ user: userOut(r.rows[0]) });
}));
me.get('/preferences', ah(async (req, res) => { res.json({ preferences: prefs.present(await prefs.get(req.user.id)) }); }));
me.put('/preferences', ah(async (req, res) => {
  const patch = parse(prefs.SCHEMA, req.body);
  res.json({ preferences: prefs.present(await prefs.update(req.user.id, patch)) });
}));

// Data portability (GDPR-style export of everything we hold, minus raw photo bytes).
me.get('/export', ah(async (req, res) => {
  const id = req.user.id;
  const q = async (sql) => (await db.query(sql, [id])).rows;
  res.json({
    exportedAt: new Date().toISOString(),
    user: userOut(req.user),
    preferences: await prefs.get(id),
    pantry: await q('SELECT name, category, quantity::float8 AS quantity, unit, status, to_char(expires_on, \'YYYY-MM-DD\') AS expires_on, added_at FROM pantry_items WHERE user_id = $1'),
    recipes: await q('SELECT title, description, ingredients, steps, servings, status, created_at, cooked_at FROM recipes WHERE user_id = $1'),
    photos: await q('SELECT id, status, detected_items, created_at FROM photos WHERE user_id = $1'),
    shoppingList: await q('SELECT name, quantity::float8 AS quantity, unit, checked FROM shopping_list_items WHERE user_id = $1'),
    savings: await q('SELECT item_name, amount_cents, created_at FROM savings_events WHERE user_id = $1'),
    stats: (await q('SELECT current_streak, longest_streak, total_saved_cents, items_rescued, meals_cooked FROM user_stats WHERE user_id = $1'))[0],
  });
}));

// Permanently deletes the account and everything attached to it (photos included).
me.delete('/', authLimiter, ah(async (req, res) => {
  const b = parse(DELETE, req.body);
  await auth.deleteAccount(req.user.id, b.password);
  res.sendStatus(204);
}));

module.exports = { authRouter, meRouter: me };
