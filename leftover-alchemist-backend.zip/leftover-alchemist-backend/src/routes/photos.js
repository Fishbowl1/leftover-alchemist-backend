'use strict';
const express = require('express');
const config = require('../config');
const { AppError, E } = require('../errors');
const { s } = require('../lib/validate');
const photos = require('../services/photos');
const { asyncHandler: ah, requireAuth, parse, rateLimit } = require('../middleware/common');

const router = express.Router();
router.use(requireAuth);

const limiter = rateLimit({ windowMs: 3600_000, max: config.rate.photosPerHour, key: (req) => req.user.id, message: 'You are scanning very quickly. Please wait a bit.' });
const CONFIRM = s.object({ items: photos.CONFIRM_ITEMS.optional() });

const id = (v) => { const n = Number(v); if (!Number.isInteger(n) || n < 1) throw E.notFound('Photo'); return n; };

// Upload: send the image as the RAW request body (Content-Type: image/jpeg | image/png | image/webp).
router.post('/', limiter,
  express.raw({ type: ['image/jpeg', 'image/png', 'image/webp'], limit: config.upload.maxBytes }),
  ah(async (req, res) => {
    if (!Buffer.isBuffer(req.body)) {
      throw new AppError(415, 'unsupported_media_type', 'Send the image as the raw request body with Content-Type image/jpeg, image/png or image/webp.');
    }
    const out = await photos.ingest(req.user, req.body, { autoAdd: req.query.autoAdd === 'true' });
    res.status(out.deduplicated ? 200 : 201).json(out);
  }));

router.get('/', ah(async (req, res) => { res.json({ photos: await photos.list(req.user.id) }); }));
router.get('/:id', ah(async (req, res) => { res.json({ photo: photos.present(await photos.getRow(req.user.id, id(req.params.id))) }); }));
router.get('/:id/image', ah(async (req, res) => {
  const img = await photos.getImage(req.user.id, id(req.params.id));
  res.set('Content-Type', img.mime_type || 'image/jpeg').set('Cache-Control', 'private, no-store').send(img.image_data);
}));
router.post('/:id/analyze', limiter, ah(async (req, res) => { res.status(200).json(await photos.retry(req.user, id(req.params.id))); }));
router.post('/:id/confirm', ah(async (req, res) => {
  const b = parse(CONFIRM, req.body || {});
  res.status(201).json(await photos.confirm(req.user, id(req.params.id), b.items));
}));
router.delete('/:id', ah(async (req, res) => { await photos.remove(req.user.id, id(req.params.id)); res.sendStatus(204); }));

module.exports = router;
