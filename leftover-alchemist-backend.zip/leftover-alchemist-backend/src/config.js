'use strict';
// Central configuration. Everything tunable lives here and can be overridden by env vars.

try { process.loadEnvFile('.env'); } catch { /* no .env file: fine */ }

const env = process.env;
const int = (v, d) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : d; };
const flt = (v, d) => { const n = parseFloat(v); return Number.isFinite(n) ? n : d; };
const usdToMicros = (usd) => Math.round(usd * 1e6);

const isProd = env.NODE_ENV === 'production';

// USD per million tokens. PLACEHOLDER DEFAULTS: set AI_PRICES_JSON to your real pricing,
// e.g. {"claude-haiku-5-5":{"in":1,"out":5}}. Unknown models fall back to the "default" entry.
let prices = {
  'claude-haiku-5-5': { in: 1, out: 5 },
  'claude-sonnet-5-5': { in: 3, out: 15 },
  default: { in: 3, out: 15 },
};
if (env.AI_PRICES_JSON) {
  try { prices = { ...prices, ...JSON.parse(env.AI_PRICES_JSON) }; } catch { /* keep defaults */ }
}

const config = {
  env: env.NODE_ENV || 'development',
  isProd,
  port: int(env.PORT, 3000),
  databaseUrl: env.DATABASE_URL || '',
  databaseSsl: env.DATABASE_SSL === 'true',
  dbPoolMax: int(env.DB_POOL_MAX, 10),
  autoMigrate: env.AUTO_MIGRATE !== 'false',
  trustProxy: int(env.TRUST_PROXY, 0), // set to 1 when behind Render/Fly/Heroku-style proxies

  sessionTtlDays: int(env.SESSION_TTL_DAYS, 30),

  upload: {
    maxBytes: int(env.UPLOAD_MAX_BYTES, 8 * 1024 * 1024),
    maxEdge: int(env.IMAGE_MAX_EDGE, 1280), // longest side after resize (also caps vision cost)
    jpegQuality: int(env.IMAGE_JPEG_QUALITY, 80),
    maxInputPixels: int(env.IMAGE_MAX_INPUT_PIXELS, 40_000_000),
  },
  photoRetentionDays: int(env.PHOTO_RETENTION_DAYS, 30), // original image bytes deleted after this

  quota: { freePhotosPerMonth: int(env.FREE_PHOTOS_PER_MONTH, 3) },

  ai: {
    apiKey: env.ANTHROPIC_API_KEY || '',
    baseUrl: env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com',
    version: '2023-06-01',
    visionModel: env.VISION_MODEL || 'claude-sonnet-5-5',
    recipeModel: env.RECIPE_MODEL || 'claude-haiku-5-5',
    timeoutMs: int(env.AI_TIMEOUT_MS, 60_000),
    maxAttempts: int(env.AI_MAX_ATTEMPTS, 3),
    backoffBaseMs: int(env.AI_BACKOFF_MS, 600),
    visionMaxTokens: 3000,
    recipeMaxTokens: 2500,
    prices,
  },

  // Hard spend limits. Each AI call is metered in ai_usage; calls are refused once a limit is hit.
  budgets: {
    freeMonthlyMicros: usdToMicros(flt(env.AI_BUDGET_FREE_USD, 0.4)),
    paidMonthlyMicros: usdToMicros(flt(env.AI_BUDGET_PAID_USD, 8)),
    globalDailyMicros: usdToMicros(flt(env.AI_BUDGET_GLOBAL_DAILY_USD, 25)),
  },

  recipe: { maxGenerations: int(env.RECIPE_MAX_GENERATIONS, 3), cacheMinutes: int(env.RECIPE_CACHE_MINUTES, 60) },

  rate: {
    globalPerMin: int(env.RATE_GLOBAL_PER_MIN, 240),
    authPer15Min: int(env.RATE_AUTH_PER_15MIN, 20),
    photosPerHour: int(env.RATE_PHOTOS_PER_HOUR, 20),
    recipesPerHour: int(env.RATE_RECIPES_PER_HOUR, 20),
  },
};

function priceFor(model) { return config.ai.prices[model] || config.ai.prices.default; }
config.priceFor = priceFor;

if (isProd && !config.databaseUrl) throw new Error('DATABASE_URL is required in production');

module.exports = config;
