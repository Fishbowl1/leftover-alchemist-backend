'use strict';
// Reliable, metered, schema-validated calls to the Anthropic Messages API (plain fetch,
// no SDK). Features: budget pre-check, timeout, retry with exponential backoff + jitter
// (honouring Retry-After), a circuit breaker, structured output via forced tool use,
// output validation (invalid output is retried), and per-call cost metering.
const config = require('../config');
const { AppError, log } = require('../errors');
const budget = require('../services/budget');
const { validate } = require('../lib/validate');

class RetryableError extends Error {}

const breaker = { failures: 0, openUntil: 0 };
const BREAKER_THRESHOLD = 5;
const BREAKER_COOLDOWN_MS = 30_000;

async function httpCreate(body) {
  if (!config.ai.apiKey) throw new AppError(503, 'ai_not_configured', 'AI features are not configured on this server (missing ANTHROPIC_API_KEY).');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), config.ai.timeoutMs);
  try {
    const res = await fetch(`${config.ai.baseUrl}/v1/messages`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': config.ai.apiKey, 'anthropic-version': config.ai.version },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* non-JSON error page */ }
    if (!res.ok) {
      const err = new Error((json && json.error && json.error.message) || `AI API returned HTTP ${res.status}`);
      err.status = res.status;
      err.apiType = json && json.error && json.error.type;
      err.retryAfter = res.headers.get('retry-after');
      throw err;
    }
    return json;
  } catch (e) {
    if (e.name === 'AbortError') { const t = new Error('AI request timed out'); t.code = 'ETIMEDOUT'; throw t; }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

const TRANSIENT_CODES = new Set(['ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED', 'EAI_AGAIN', 'UND_ERR_SOCKET', 'UND_ERR_CONNECT_TIMEOUT']);
function isTransient(err) {
  if (err instanceof RetryableError) return true;
  if (err.status) return [408, 409, 429].includes(err.status) || err.status >= 500;
  const networkFailure = err.name === 'TypeError' && /fetch failed/i.test(err.message); // undici's network error
  return TRANSIENT_CODES.has(err.code) || (err.cause && TRANSIENT_CODES.has(err.cause.code)) || networkFailure;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function backoffMs(attempt, err) {
  const ra = err && err.retryAfter ? Number(err.retryAfter) : NaN;
  if (Number.isFinite(ra) && ra >= 0) return Math.min(ra * 1000, 10_000);
  const base = config.ai.backoffBaseMs * 2 ** (attempt - 1);
  return Math.min(base + Math.random() * base * 0.5, 10_000);
}

const summarizeErrors = (errs) => errs.slice(0, 3).map((e) => `${e.path || 'output'} ${e.message}`).join('; ');

// params: { user, kind, model, system, content, tool: {name, description, input_schema}, schema, maxTokens }
async function callStructured({ user, kind, model, system, content, tool, schema, maxTokens }) {
  await budget.assertWithinBudget(user);
  if (Date.now() < breaker.openUntil) {
    throw new AppError(503, 'ai_unavailable', 'Our AI service is temporarily unavailable. Please try again in a minute.');
  }
  const started = Date.now();
  const max = config.ai.maxAttempts;
  let inTok = 0;
  let outTok = 0;
  let lastErr = null;
  let attempts = 0;

  for (let attempt = 1; attempt <= max; attempt++) {
    attempts = attempt;
    try {
      const resp = await httpCreate({
        model,
        max_tokens: maxTokens,
        system,
        tools: [tool],
        tool_choice: { type: 'tool', name: tool.name },
        messages: [{ role: 'user', content }],
      });
      inTok += (resp.usage && resp.usage.input_tokens) || 0;
      outTok += (resp.usage && resp.usage.output_tokens) || 0;
      if (resp.stop_reason === 'max_tokens') throw new RetryableError('model output was truncated');
      const block = (resp.content || []).find((b) => b.type === 'tool_use' && b.name === tool.name);
      if (!block) throw new RetryableError('model did not return structured output');
      const v = validate(schema, block.input);
      if (!v.ok) throw new RetryableError(`model output failed validation: ${summarizeErrors(v.errors)}`);

      breaker.failures = 0;
      const cost = await budget.record({ userId: user && user.id, kind, model, inputTokens: inTok, outputTokens: outTok, status: 'ok', attempts, latencyMs: Date.now() - started });
      return { data: v.value, model, attempts, usage: { inputTokens: inTok, outputTokens: outTok, costMicros: cost } };
    } catch (err) {
      lastErr = err;
      if (!isTransient(err) || attempt === max) break;
      log.warn('ai call failed, retrying', { kind, attempt, status: err.status, msg: err.message });
      await sleep(backoffMs(attempt, err));
    }
  }

  if (isTransient(lastErr)) { breaker.failures += 1; if (breaker.failures >= BREAKER_THRESHOLD) breaker.openUntil = Date.now() + BREAKER_COOLDOWN_MS; }
  try {
    await budget.record({ userId: user && user.id, kind, model, inputTokens: inTok, outputTokens: outTok, status: 'error', attempts, latencyMs: Date.now() - started, error: lastErr.message });
  } catch (e) { log.error('failed to record ai usage', { err: e }); }
  log.error('ai call failed', { kind, attempts, status: lastErr.status, msg: lastErr.message });

  if (lastErr instanceof AppError) throw lastErr;
  if (lastErr instanceof RetryableError) throw new AppError(502, 'ai_bad_output', 'The AI returned something we could not use. Please try again.');
  if (isTransient(lastErr)) throw new AppError(503, 'ai_unavailable', 'Our AI service is busy right now. Please try again in a minute.');
  throw new AppError(502, 'ai_error', 'Something went wrong with our AI service. Please try again later.');
}

function resetBreaker() { breaker.failures = 0; breaker.openUntil = 0; }

module.exports = { callStructured, resetBreaker };
