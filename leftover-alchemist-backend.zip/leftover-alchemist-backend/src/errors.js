'use strict';

class AppError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

const E = {
  badRequest: (code, msg, details) => new AppError(400, code, msg, details),
  unauthorized: (msg = 'Please sign in.') => new AppError(401, 'unauthorized', msg),
  paymentRequired: (code, msg, details) => new AppError(402, code, msg, details),
  forbidden: (code, msg) => new AppError(403, code, msg),
  notFound: (what = 'Resource') => new AppError(404, 'not_found', `${what} not found.`),
  conflict: (code, msg, details) => new AppError(409, code, msg, details),
  unprocessable: (code, msg, details) => new AppError(422, code, msg, details),
  tooMany: (code, msg, details) => new AppError(429, code, msg, details),
};

// Minimal structured logger: one JSON object per line, never logs bodies, tokens or images.
function emit(level, msg, ctx = {}) {
  if (process.env.NODE_ENV === 'test' && !process.env.LOG_TESTS) return;
  const out = { t: new Date().toISOString(), level, msg };
  for (const [k, v] of Object.entries(ctx)) {
    out[k] = v instanceof Error ? { name: v.name, message: v.message, code: v.code, stack: process.env.NODE_ENV === 'production' ? undefined : v.stack } : v;
  }
  (level === 'error' ? process.stderr : process.stdout).write(`${JSON.stringify(out)}\n`);
}
const log = {
  info: (m, c) => emit('info', m, c),
  warn: (m, c) => emit('warn', m, c),
  error: (m, c) => emit('error', m, c),
};

module.exports = { AppError, E, log };
