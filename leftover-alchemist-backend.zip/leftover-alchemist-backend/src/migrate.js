'use strict';
// Applies migrations/*.sql in filename order, once each. Safe to run on every start.
const fs = require('fs');
const path = require('path');
const db = require('./db');
const { log } = require('./errors');

const DIR = path.join(__dirname, '..', 'migrations');

async function migrate() {
  const client = await db.getPool().connect();
  try {
    await client.query('SELECT pg_advisory_lock(727274)'); // one migrator at a time across instances
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      name TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`);
    const done = new Set((await client.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name));
    const files = fs.readdirSync(DIR).filter((f) => f.endsWith('.sql')).sort();
    const applied = [];
    for (const f of files) {
      if (done.has(f)) continue;
      const sql = fs.readFileSync(path.join(DIR, f), 'utf8');
      try {
        await client.query('BEGIN');
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
        await client.query('COMMIT');
        applied.push(f);
        log.info('migration applied', { file: f });
      } catch (err) {
        await client.query('ROLLBACK');
        throw new Error(`Migration ${f} failed: ${err.message}`);
      }
    }
    return applied;
  } finally {
    try { await client.query('SELECT pg_advisory_unlock(727274)'); } catch { /* ignore */ }
    client.release();
  }
}

module.exports = { migrate };

if (require.main === module) {
  migrate()
    .then((a) => { console.log(a.length ? `Applied: ${a.join(', ')}` : 'Database is up to date.'); return db.close(); })
    .catch((e) => { console.error(e.message); process.exit(1); });
}
